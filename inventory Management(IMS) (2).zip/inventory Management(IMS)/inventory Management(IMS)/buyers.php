<?php
session_start();
if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit();
}

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "inventory";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$undoStack = $_SESSION['undoStack'] ?? [];
$redoStack = $_SESSION['redoStack'] ?? [];

function saveState($conn) {
    global $undoStack;
    $result = $conn->query("SELECT * FROM buyers ORDER BY id ASC");
    $state = [];
    while ($row = $result->fetch_assoc()) {
        $state[] = $row;
    }
    array_push($undoStack, $state);
    if (count($undoStack) > 5) {
        array_shift($undoStack);
    }
    $_SESSION['undoStack'] = $undoStack;
}

function restoreState($conn, $state) {
    $conn->query("DELETE FROM buyers");
    foreach ($state as $row) {
        $conn->query("INSERT INTO buyers (id, date, name, address, contact, product_id, product, type, rate, quantity, total)
                      VALUES ({$row['id']}, '{$row['date']}', '{$row['name']}', '{$row['address']}', '{$row['contact']}', '{$row['product_id']}', '{$row['product']}', '{$row['type']}', '{$row['rate']}', '{$row['quantity']}', '{$row['total']}')");
    }
}

// Handle form submission for adding/updating buyers
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    saveState($conn);

    $id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
    $date = $_POST['date'];
    $name = $_POST['name'];
    $address = $_POST['address'];
    $contact = $_POST['contact'];
    $product_id = $_POST['product_id'];
    $product = $_POST['product'];
    $type = $_POST['type'];
    $rate = $_POST['rate'];
    $quantity = $_POST['quantity'];
    $total = $rate * $quantity;

    if ($id > 0) {
        // Update existing record
        $sql = "UPDATE buyers SET 
                date='$date', 
                name='$name', 
                address='$address', 
                contact='$contact', 
                product_id='$product_id', 
                product='$product', 
                type='$type', 
                rate='$rate', 
                quantity='$quantity', 
                total='$total'
                WHERE id=$id";
    } else {
        // Insert new record
        $sql = "INSERT INTO buyers (date, name, address, contact, product_id, product, type, rate, quantity, total)
                VALUES ('$date', '$name', '$address', '$contact', '$product_id', '$product', '$type', '$rate', '$quantity', '$total')";
    }

    if ($conn->query($sql) === TRUE) {
        echo "Record saved successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    // Reset the auto increment id
    $conn->query("ALTER TABLE buyers AUTO_INCREMENT = 1");

    // End the session for add product
    unset($_SESSION['add_product']);
    header('Location: buyers.php');
    exit();
}

// Handle delete
if (isset($_GET['delete'])) {
    saveState($conn);
    $id = (int)$_GET['delete'];
    $conn->query("DELETE FROM buyers WHERE id=$id");
    $conn->query("ALTER TABLE buyers AUTO_INCREMENT = 1");
}

// Handle search
$search = '';
if (isset($_GET['search'])) {
    $search = $conn->real_escape_string($_GET['search']);
}

// Fetch record to edit
$edit_id = 0;
$edit_record = null;
if (isset($_GET['edit'])) {
    $edit_id = (int)$_GET['edit'];
    $result = $conn->query("SELECT * FROM buyers WHERE id=$edit_id");
    $edit_record = $result->fetch_assoc();
    $_SESSION['add_product'] = true; // Ensure form is displayed
}

// Start a session for add product when 'add' is set
if (isset($_GET['add'])) {
    $_SESSION['add_product'] = true;
}

// End the session for add product when 'cancel' is set
if (isset($_GET['cancel'])) {
    unset($_SESSION['add_product']);
    header('Location: buyers.php');
    exit();
}

// Handle undo
if (isset($_GET['undo']) && !empty($undoStack)) {
    $redoStack[] = $undoStack[count($undoStack) - 1];
    $state = array_pop($undoStack);
    restoreState($conn, $state);
    $_SESSION['undoStack'] = $undoStack;
    $_SESSION['redoStack'] = $redoStack;
    header('Location: buyers.php');
    exit();
}

// Handle redo
if (isset($_GET['redo']) && !empty($redoStack)) {
    $undoStack[] = $redoStack[count($redoStack) - 1];
    $state = array_pop($redoStack);
    restoreState($conn, $state);
    $_SESSION['undoStack'] = $undoStack;
    $_SESSION['redoStack'] = $redoStack;
    header('Location: buyers.php');
    exit();
}

// Pagination logic
$records_per_page = 10;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$start_from = ($page - 1) * $records_per_page;
$sql_count = "SELECT COUNT(*) FROM buyers";
if ($search) {
    $sql_count .= " WHERE name LIKE '%$search%' OR address LIKE '%$search%' OR contact LIKE '%$search%' OR product_id LIKE '%$search%' OR product LIKE '%$search%' OR type LIKE '%$search%'";
}
$total_records_result = $conn->query($sql_count);
$total_records = $total_records_result->fetch_array()[0];
$total_pages = ceil($total_records / $records_per_page);

$sql = "SELECT * FROM buyers";
if ($search) {
    $sql .= " WHERE name LIKE '%$search%' OR address LIKE '%$search%' OR contact LIKE '%$search%' OR product_id LIKE '%$search%' OR product LIKE '%$search%' OR type LIKE '%$search%'";
}
$sql .= " ORDER BY id ASC LIMIT $start_from, $records_per_page";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Buyers In Management</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: gainsboro;
            background-image: url('dash.png');
        }

        .top-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px;
            background-color: #3f51b5;
        }
        .search-bar {
            flex-grow: 1;
            display: flex;
            justify-content: center;
        }
        .search-bar input {
            padding: 10px;
            font-size: 16px;
            width: 300px;
        }
        .search-bar button {
            padding: 10px;
            background-color: #007BFF;
            color: white;
            border: none;
            cursor: pointer;
        }

        .top-bar input {
            padding: 10px;
            font-size: 16px;
            margin-right: 10px;
        }

        .top-bar button {
            padding: 10px;
            background-color: #007BFF;
            color: white;
            border: none;
            cursor: pointer;
            margin-left: 10px;
        }

        .content {
            margin: 20px;
            background-color: #222;
            padding: 20px;
            border-radius: 8px;
        }

        h1 {
            color: #fff;
            text-align: center;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            text-align: center;
        }

        th, td {
            padding: 12px;
            border: 1px solid #ddd;
            text-align: left;
            color: #fff;
        }

        th {
            background-color: #444;
        }

        th:nth-child(1) {
            background-color: #FF0000; /* Red */
        }

        th:nth-child(2) {
            background-color: #FF7F00; /* Orange */
        }

        th:nth-child(3) {
            background-color: #FFFF00; /* Yellow */
        }

        th:nth-child(4) {
            background-color: #00FF00; /* Green */
        }

        th:nth-child(5) {
            background-color: #0000FF; /* Blue */
        }

        th:nth-child(6) {
            background-color: #4B0082; /* Indigo */
        }

        th:nth-child(7) {
            background-color: #9400D3; /* Violet */
        }

        th:nth-child(8) {
            background-color: #FF00FF; /* Magenta */
        }

        th:nth-child(9) {
            background-color: #00FFFF; /* Cyan */
        }

        th:nth-child(10) {
            background-color: #8B4513; /* Brown */
        }

        th:nth-child(11) {
            background-color: #FFC0CB; /* Pink */
        }

        .form-section {
            margin-top: 20px;
        }

        #newBuyersForm {
            display: <?php echo isset($_SESSION['add_product']) ? 'flex' : 'none'; ?>;
            flex-wrap: wrap;
            background-color: #333;
            padding: 20px;
            border-radius: 8px;
            color: #fff;
        }

        #newBuyersForm input, #newBuyersForm button {
            margin-bottom: 20px;
            padding: 10px;
            font-size: 16px;
            margin-right: 10px;
            flex: 1 1 30%;
        }

        #newBuyersForm button {
            border: none;
            cursor: pointer;
            flex: 1 1 20%;
        }

        .btn.save {
            background-color: #28a745;
            color: white;
        }

        .btn.cancel {
            background-color: #6c757d;
            color: white;
        }

        .btn.edit {
            background-color: #28a745;
            color: white;
        }

        .btn.delete {
            background-color: #dc3545;
            color: white;
        }

        .btn.print {
            background-color: #ffc107;
            color: black;
        }

        .pagination {
            display: flex;
            justify-content: center;
            margin-top: 20px;
        }

        .pagination a {
            padding: 10px;
            margin: 0 5px;
            background-color: #3f51b5;
            color: white;
            text-decoration: none;
            font-weight: bold;
            border-radius: 4px;
        }

        .pagination a.active {
            background-color: #ff5722;
        }

        .pagination a:visited {
            color: white;
        }

        .pagination .prev, .pagination .next {
            font-size: 18px;
        }

        .user-menu {
            display: flex;
            align-items: center;
            justify-content: flex-end;
            position: relative;
        }

        .user-icon img {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            cursor: pointer;
        }

        .user-dropdown {
            display: none;
            position: absolute;
            top: 50px;
            right: 0;
            color: black;
            background-color: #fff;
            border: 1px solid #ccc;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            z-index: 1;
        }

        .user-dropdown.show {
            display: block;
        }

        .user-dropdown a {
            display: block;
            padding: 10px;
            text-decoration: none;
            color: #333;
        }

        .user-dropdown a:hover {
            background-color: #000000;
        }
    </style>
</head>
<body>
<div class="user-menu">
            <div class="user-icon">
                <img src="icon.png" alt="User Icon">
            </div>
            <div class="user-dropdown">
                <a href="profile.php">Profile</a>
                <a href="logout.php">Logout</a>
            </div>
        </div>
<div class="content">
<h1>Buyers In Management</h1>
    <div class="top-bar">
    <button onclick="location.href='dashboard.php'">Home</button>
    <form method="GET" action="buyers.php" class="search-bar">
    <input type="text" name="search" value="<?php echo htmlspecialchars($search); ?>" placeholder="Search...">
    <button type="submit">Search</button>
        </form>
        <button onclick="location.href='buyers.php?add=true'">Add Buyer</button>
        <button id="printBtn" class="btn print" onclick="window.print()">Print</button>
    </div>
    

        <div class="form-section">
            <form id="newBuyersForm" method="post" action="">
                <input type="hidden" name="id" value="<?php echo $edit_record['id'] ?? ''; ?>">
                <input type="date" name="date" placeholder="Date" value="<?php echo $edit_record['date'] ?? ''; ?>" required>
                <input type="text" name="name" placeholder="Name" value="<?php echo $edit_record['name'] ?? ''; ?>" required>
                <input type="text" name="address" placeholder="Address" value="<?php echo $edit_record['address'] ?? ''; ?>" required>
                <input type="text" name="contact" placeholder="Contact" value="<?php echo $edit_record['contact'] ?? ''; ?>" required>
                <input type="text" name="product_id" placeholder="Product ID" value="<?php echo $edit_record['product_id'] ?? ''; ?>" required>
                <input type="text" name="product" placeholder="Product" value="<?php echo $edit_record['product'] ?? ''; ?>" required>
                <input type="text" name="type" placeholder="Type" value="<?php echo $edit_record['type'] ?? ''; ?>" required>
                <input type="number" name="rate" placeholder="Rate" value="<?php echo $edit_record['rate'] ?? ''; ?>" required>
                <input type="number" name="quantity" placeholder="Quantity" value="<?php echo $edit_record['quantity'] ?? ''; ?>" required>
                <button class="btn save" type="submit">Save</button>
                <button class="btn cancel" type="button" onclick="location.href='buyers.php?cancel=true'">Cancel</button>
            </form>
        </div>

        <table>
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Name</th>
                    <th>Address</th>
                    <th>Contact</th>
                    <th>Product ID</th>
                    <th>Product</th>
                    <th>Type</th>
                    <th>Rate</th>
                    <th>Quantity</th>
                    <th>Total</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $result->fetch_assoc()) : ?>
                    <tr>
                        <td><?php echo $row['date']; ?></td>
                        <td><?php echo $row['name']; ?></td>
                        <td><?php echo $row['address']; ?></td>
                        <td><?php echo $row['contact']; ?></td>
                        <td><?php echo $row['product_id']; ?></td>
                        <td><?php echo $row['product']; ?></td>
                        <td><?php echo $row['type']; ?></td>
                        <td><?php echo $row['rate']; ?></td>
                        <td><?php echo $row['quantity']; ?></td>
                        <td><?php echo $row['total']; ?></td>
                        <td>
                            <button class="btn edit" onclick="location.href='buyers.php?edit=<?php echo $row['id']; ?>'">Edit</button>
                            <button class="btn delete" onclick="location.href='buyers.php?delete=<?php echo $row['id']; ?>'">Delete</button>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>

        <div class="pagination">
            <?php if ($page > 1) : ?>
                <a href="buyers.php?page=<?php echo $page - 1; ?>" class="prev">&laquo; Previous</a>
            <?php endif; ?>
            <?php for ($i = 1; $i <= $total_pages; $i++) : ?>
                <a href="buyers.php?page=<?php echo $i; ?>" class="<?php echo $page == $i ? 'active' : ''; ?>"><?php echo $i; ?></a>
            <?php endfor; ?>
            <?php if ($page < $total_pages) : ?>
                <a href="buyers.php?page=<?php echo $page + 1; ?>" class="next">Next &raquo;</a>
            <?php endif; ?>
        </div>
    </div>

    <script>
        document.querySelector('.user-icon img').addEventListener('click', function() {
            document.querySelector('.user-dropdown').classList.toggle('show');
        });

        window.onclick = function(event) {
            if (!event.target.matches('.user-icon img')) {
                var dropdowns = document.getElementsByClassName("user-dropdown");
                for (var i = 0; i < dropdowns.length; i++) {
                    var openDropdown = dropdowns[i];
                    if (openDropdown.classList.contains('show')) {
                        openDropdown.classList.remove('show');
                    }
                }
            }
        }
    </script>
</body>
</html>
