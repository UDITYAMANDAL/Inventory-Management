<?php
session_start();
if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit();
}

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "inventory";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$undoStack = $_SESSION['undoStack'] ?? [];
$redoStack = $_SESSION['redoStack'] ?? [];

function saveState($conn) {
    global $undoStack;
    $result = $conn->query("SELECT * FROM stockout ORDER BY id ASC");
    $state = [];
    while ($row = $result->fetch_assoc()) {
        $state[] = $row;
    }
    array_push($undoStack, $state);
    if (count($undoStack) > 5) {
        array_shift($undoStack);
    }
    $_SESSION['undoStack'] = $undoStack;
}

function restoreState($conn, $state) {
    $conn->query("DELETE FROM stockout");
    foreach ($state as $row) {
        $conn->query("INSERT INTO stockout (id, date, prodid, prodname, prodtype, prodrate, prodquantity, sellerdetails, prodimage)
                      VALUES ({$row['id']}, '{$row['date']}', '{$row['prodid']}', '{$row['prodname']}', '{$row['prodtype']}', '{$row['prodrate']}', '{$row['prodquantity']}', '{$row['sellerdetails']}', '{$row['prodimage']}')");
    }
}

// Handle form submission for adding/updating stockout
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    saveState($conn);

    $id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
    $date = $_POST['date'];
    $prodid = $_POST['prodid'];
    $prodname = $_POST['prodname'];
    $prodtype = $_POST['prodtype'];
    $prodrate = $_POST['prodrate'];
    $prodquantity = $_POST['prodquantity'];
    $sellerdetails = $_POST['sellerdetails'];
    $prodimage = $_POST['existing_image'] ?? '';

    if (isset($_FILES['prodimage']) && $_FILES['prodimage']['error'] == 0) {
        $prodimage = 'uploads/' . basename($_FILES['prodimage']['name']);
        move_uploaded_file($_FILES['prodimage']['tmp_name'], $prodimage);
    }

    if ($id > 0) {
        // Update existing record
        $sql = "UPDATE stockout SET 
                date='$date', 
                prodid='$prodid', 
                prodname='$prodname', 
                prodtype='$prodtype', 
                prodrate='$prodrate', 
                prodquantity='$prodquantity', 
                sellerdetails='$sellerdetails',
                prodimage='$prodimage'
                WHERE id=$id";
    } else {
        // Insert new record
        $sql = "INSERT INTO stockout (date, prodid, prodname, prodtype, prodrate, prodquantity, sellerdetails, prodimage)
                VALUES ('$date', '$prodid', '$prodname', '$prodtype', '$prodrate', '$prodquantity', '$sellerdetails', '$prodimage')";
    }

    if ($conn->query($sql) === TRUE) {
        echo "Record saved successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    // Reset the auto increment id
    $conn->query("ALTER TABLE stockout AUTO_INCREMENT = 1");

    // End the session for add product
    unset($_SESSION['add_product']);
    header('Location: stockout.php');
    exit();
}

// Handle delete
if (isset($_GET['delete'])) {
    saveState($conn);
    $id = (int)$_GET['delete'];
    $conn->query("DELETE FROM stockout WHERE id=$id");
    $conn->query("ALTER TABLE stockout AUTO_INCREMENT = 1");
}

// Handle search
$search = '';
if (isset($_GET['search'])) {
    $search = $conn->real_escape_string($_GET['search']);
}

// Fetch record to edit
$edit_id = 0;
$edit_record = null;
if (isset($_GET['edit'])) {
    $edit_id = (int)$_GET['edit'];
    $result = $conn->query("SELECT * FROM stockout WHERE id=$edit_id");
    $edit_record = $result->fetch_assoc();
    $_SESSION['add_product'] = true; // Ensure form is displayed
}

// Start a session for add product when 'add' is set
if (isset($_GET['add'])) {
    $_SESSION['add_product'] = true;
}

// End the session for add product when 'cancel' is set
if (isset($_GET['cancel'])) {
    unset($_SESSION['add_product']);
    header('Location: stockout.php');
    exit();
}

// Handle undo
if (isset($_GET['undo']) && !empty($undoStack)) {
    $redoStack[] = $undoStack[count($undoStack) - 1];
    $state = array_pop($undoStack);
    restoreState($conn, $state);
    $_SESSION['undoStack'] = $undoStack;
    $_SESSION['redoStack'] = $redoStack;
    header('Location: stockout.php');
    exit();
}

// Handle redo
if (isset($_GET['redo']) && !empty($redoStack)) {
    $undoStack[] = $redoStack[count($redoStack) - 1];
    $state = array_pop($redoStack);
    restoreState($conn, $state);
    $_SESSION['undoStack'] = $undoStack;
    $_SESSION['redoStack'] = $redoStack;
    header('Location: stockout.php');
    exit();
}

// Pagination logic
$records_per_page = 10;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$start_from = ($page - 1) * $records_per_page;
$sql_count = "SELECT COUNT(*) FROM stockout";
if ($search) {
    $sql_count .= " WHERE prodrate LIKE '%$search%' OR sellerdetails LIKE '%$search%' OR prodquantity LIKE '%$search%' OR prodtype LIKE '%$search%' OR prodname LIKE '%$search%' OR prodid LIKE '%$search%'";
}
$total_records_result = $conn->query($sql_count);
$total_records = $total_records_result->fetch_array()[0];
$total_pages = ceil($total_records / $records_per_page);

$sql = "SELECT * FROM stockout";
if ($search) {
    $sql .= " WHERE prodrate LIKE '%$search%' OR sellerdetails LIKE '%$search%' OR prodquantity LIKE '%$search%' OR prodtype LIKE '%$search%' OR prodname LIKE '%$search%' OR prodid LIKE '%$search%'";
}
$sql .= " ORDER BY id ASC LIMIT $start_from, $records_per_page";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stockout In Management</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background: url('dash.png') no-repeat center center fixed;
            background-size: cover;
            color: white;
        }
        .top-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px;
            background-color: #3f51b5;
        }
        .search-bar {
            flex-grow: 1;
            display: flex;
            justify-content: center;
        }
        .search-bar input {
            padding: 10px;
            font-size: 16px;
            width: 300px;
        }
        .search-bar button {
            padding: 10px;
            background-color: #007BFF;
            color: white;
            border: none;
            cursor: pointer;
        }
        .top-bar button {
            padding: 10px;
            background-color: #007BFF;
            color: white;
            border: none;
            cursor: pointer;
        }
        .actions {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .actions button {
            padding: 10px;
            background-color: #007BFF;
            color: white;
            border: none;
            cursor: pointer;
        }
        .content {
            margin: 20px;
            background-color: #222;
            padding: 20px;
            border-radius: 8px;
        }
        h1 {
            color: #fff;
            text-align: center;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            padding: 12px;
            border: 1px solid #ddd;
            text-align: left;
            color: #fff;
        }
        th:nth-child(1) {
            background-color: #f44336;
        }
        th:nth-child(2) {
            background-color: #e91e63;
        }
        th:nth-child(3) {
            background-color: #9c27b0;
        }
        th:nth-child(4) {
            background-color: #673ab7;
        }
        th:nth-child(5) {
            background-color: #3f51b5;
        }
        th:nth-child(6) {
            background-color: #2196f3;
        }
        th:nth-child(7) {
            background-color: #03a9f4;
        }
        th:nth-child(8) {
            background-color: #00bcd4;
        }
        th:nth-child(9) {
            background-color: #009688;
        }
        th:nth-child(10) {
            background-color: #4caf50;
        }
        td {
            background-color: #333;
        }
        .form-section {
            margin-top: 20px;
        }
        #newBuyerForm {
            display: <?php echo isset($_SESSION['add_product']) ? 'block' : 'none'; ?>;
        }
        #newBuyerForm input {
            margin-bottom: 20px;
            padding: 10px;
            font-size: 16px;
            flex: 1 1 30%;
            margin-right: 10px;
        }
        #newBuyerForm button {
            padding: 10px;
            margin-right: 10px;
            border: none;
            cursor: pointer;
            flex: 1 1 20%;
        }
        .btn.save {
            background-color: green;
            color: white;
        }
        .btn.cancel {
            background-color: red;
            color: white;
        }
        .btn.edit {
            background-color: green;
            color: white;
        }
        .btn.delete {
            background-color: red;
            color: white;
        }
        .user-menu {
            display: flex;
            align-items: center;
            justify-content: flex-end;
            position: relative;
        }
        .user-icon img {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            cursor: pointer;
        }
        .user-dropdown {
            display: none;
            position: absolute;
            top: 50px;
            right: 0;
            color: black;
            background-color: #fff;
            border: 1px solid #ccc;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            z-index: 1;
        }
        .user-dropdown.show {
            display: block;
        }
        .user-dropdown a {
            display: block;
            padding: 10px;
            text-decoration: none;
            color: #333;
        }
        .user-dropdown a:hover {
            background-color: #000000;
        }
        .pagination {
            display: flex;
            justify-content: center;
            margin-top: 20px;
        }
        .pagination a {
            padding: 10px;
            margin: 0 5px;
            background-color: #3f51b5;
            color: white;
            text-decoration: none;
            font-weight: bold;
            border-radius: 4px;
        }
        .pagination a.active {
            background-color: #ff5722;
        }
        .pagination a:visited {
            color: white;
        }
        .pagination .prev, .pagination .next {
            font-size: 18px;
        }
    </style>
</head>
<body>
<div class="user-menu">
                    <div class="user-icon">
                        <img src="icon.png" alt="User Icon">
                    </div>
                    <div class="user-dropdown">
                        <a href="logout.php">Logout</a>
                    </div>
                </div>
    <div class="content">
        <h1>Stockout In Management</h1>

        <div class="top-bar">
        <button onclick="location.href='dashboard.php'">Home</button>
            <form method="GET" action="stockout.php" class="search-bar">
                <input type="text" name="search" value="<?php echo htmlspecialchars($search); ?>" placeholder="Search...">
                <button type="submit">Search</button>
            </form>
            <div class="actions">
            <button id="addProductBtn" onclick="window.location.href='stockout.php?add=true'">Add Product</button>
                <button id="printBtn" class="btn print" onclick="window.print()">Print</button>
                
            </div>
        </div>

        <table>
            <tr>
                <th>Date</th>
                <th>Product ID</th>
                <th>Product Name</th>
                <th>Product Type</th>
                <th>Product Rate</th>
                <th>Product Quantity</th>
                <th>Seller Details</th>
                <th>Product Image</th>
                <th>Actions</th>
            </tr>
            <?php
            if ($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                    echo "<tr>
                            <td>" . $row["date"] . "</td>
                            <td>" . $row["prodid"] . "</td>
                            <td>" . $row["prodname"] . "</td>
                            <td>" . $row["prodtype"] . "</td>
                            <td>" . $row["prodrate"] . "</td>
                            <td>" . $row["prodquantity"] . "</td>
                            <td>" . $row["sellerdetails"] . "</td>
                            <td><img src='" . $row["prodimage"] . "' alt='Product Image' width='50'></td>
                            <td>
                                <a href='stockout.php?delete=" . $row["id"] . "' class='btn delete'>Delete</a>
                                <a href='stockout.php?edit=" . $row["id"] . "' class='btn edit'>Edit</a>
                            </td>
                          </tr>";
                }
            } else {
                echo "<tr><td colspan='10'>No records found</td></tr>";
            }
            ?>
        </table>
        <div class="form-section">
            <form method="POST" action="stockout.php" id="newBuyerForm" enctype="multipart/form-data">
                <input type="hidden" name="id" value="<?php echo $edit_id; ?>">
                <input type="hidden" name="existing_image" value="<?php echo $edit_record['prodimage'] ?? ''; ?>">
                <input type="date" name="date" value="<?php echo $edit_record['date'] ?? ''; ?>" placeholder="Date" required>
                <input type="text" name="prodid" value="<?php echo $edit_record['prodid'] ?? ''; ?>" placeholder="Product ID" required>
                <input type="text" name="prodname" value="<?php echo $edit_record['prodname'] ?? ''; ?>" placeholder="Product Name" required>
                <input type="text" name="prodtype" value="<?php echo $edit_record['prodtype'] ?? ''; ?>" placeholder="Product Type" required>
                <input type="text" name="prodrate" value="<?php echo $edit_record['prodrate'] ?? ''; ?>" placeholder="Product Rate" required>
                <input type="text" name="prodquantity" value="<?php echo $edit_record['prodquantity'] ?? ''; ?>" placeholder="Product Quantity" required>
                <input type="text" name="sellerdetails" value="<?php echo $edit_record['sellerdetails'] ?? ''; ?>" placeholder="Seller Details" required>
                <input type="file" name="prodimage">
                <button type="submit" name="save" class="btn save">Save</button>
                <button type="button" class="btn cancel" onclick="window.location.href='?cancel=true'">Cancel</button>
            </form>
        </div>
        <div class="pagination">
            <?php
            for ($i = 1; $i <= $total_pages; $i++) {
                $active = ($page == $i) ? 'active' : '';
                echo "<a href='?page=" . $i . "&search=" . urlencode($search) . "' class='" . $active . "'>" . $i . "</a>";
            }
            ?>
            <?php if ($page > 1): ?>
                <a href="?page=<?php echo $page - 1; ?>&search=<?php echo urlencode($search); ?>" class="prev">&laquo; Previous</a>
            <?php endif; ?>
            <?php if ($page < $total_pages): ?>
                <a href="?page=<?php echo $page + 1; ?>&search=<?php echo urlencode($search); ?>" class="next">Next &raquo;</a>
            <?php endif; ?>
        </div>
    </div>
    <script>
        document.querySelector('.user-icon').addEventListener('click', function() {
            document.querySelector('.user-dropdown').classList.toggle('show');
        });
    </script>
</body>
</html>

