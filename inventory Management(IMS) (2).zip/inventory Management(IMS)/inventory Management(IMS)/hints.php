<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}
$hint_answers = $_SESSION['hint_answers'];
$questions = array_keys($hint_answers);
shuffle($questions);
$selected_hints = array_slice($questions, 0, 2);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $dob = $_POST["dob"];
    $hint1 = $_POST["hint1"];
    $hint2 = $_POST["hint2"];
    
    if ($dob == $_SESSION['dob'] && $hint_answers[$selected_hints[0]] == $hint1 && $hint_answers[$selected_hints[1]] == $hint2) {
        header('Location: reset.php');
        exit;
    } else {
        echo "Verification failed.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verify Information</title>
</head>
<body>
    <div class="form-container">
        <h2>Verify Information</h2>
        <form method="post">
            <label for="dob">Date of Birth:</label>
            <input type="date" id="dob" name="dob" required><br>
            <label for="hint1"><?php echo $selected_hints[0]; ?></label>
            <input type="text" id="hint1" name="hint1" required><br>
            <label for="hint2"><?php echo $selected_hints[1]; ?></label>
            <input type="text" id="hint2" name="hint2" required><br>
            <button type="submit">Submit</button>
        </form>
    </div>
</body>
</html>
