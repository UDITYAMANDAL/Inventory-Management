<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "inventory";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

function generateHints($hint_answers) {
    $questions = array_keys($hint_answers);
    shuffle($questions);
    return array_slice($questions, 0, 2);
}

$notification = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['action']) && $_POST['action'] == 'back_to_step_1') {
        $_SESSION['step'] = 1;
    } elseif (isset($_POST["email_or_username"])) {
        $email_or_username = $_POST["email_or_username"];
        $query = $conn->prepare("SELECT * FROM data1 WHERE email=? OR username=? LIMIT 1");
        $query->bind_param("ss", $email_or_username, $email_or_username);
        $query->execute();
        $result = $query->get_result();

        if ($result->num_rows == 1) {
            $row = $result->fetch_assoc();
            $_SESSION['username'] = $row['username'];
            $_SESSION['dob'] = $row['dob'];
            $_SESSION['hint_answers'] = [
                'What is your mother DOB ?' => $row['hint_answer1'],
                'Which is your childhood bestfriend ?' => $row['hint_answer2'],
                'Who is your favourite superhero?' => $row['hint_answer3'],
                'Which is your favourite webseries?' => $row['hint_answer4'],
                'Which animal you prefer as a pet much ?' => $row['hint_answer5']
            ];
            $_SESSION['selected_hints'] = generateHints($_SESSION['hint_answers']);
            $_SESSION['step'] = 2;
        } else {
            $notification = "Email or username not found.";
        }
    } elseif (isset($_POST["dob"], $_POST["hint1"], $_POST["hint2"]) && isset($_SESSION['step']) && $_SESSION['step'] == 2) {
        $dob = $_POST["dob"];
        $hint1 = $_POST["hint1"];
        $hint2 = $_POST["hint2"];

        if ($dob == $_SESSION['dob'] && 
            $_SESSION['hint_answers'][$_SESSION['selected_hints'][0]] == $hint1 && 
            $_SESSION['hint_answers'][$_SESSION['selected_hints'][1]] == $hint2) {
            $_SESSION['verified'] = true;
            $_SESSION['step'] = 3;
        } else {
            $notification = "Verification failed.";
        }
    } elseif (isset($_POST["new_password"], $_POST["confirm_password"]) && isset($_SESSION['step']) && $_SESSION['step'] == 3) {
        if ($_POST["new_password"] == $_POST["confirm_password"]) {
            $new_password = $_POST["new_password"];
            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
            $username = $_SESSION['username'];
            $query = $conn->prepare("UPDATE data1 SET password=? WHERE username=?");
            $query->bind_param("ss", $hashed_password, $username);

            if ($query->execute()) {
                $notification = "Password reset successfully.";
                session_destroy();
                header('Location: login.php');
                exit;
            } else {
                $notification = "Error: " . $query->error;
            }
        } else {
            $notification = "Passwords do not match.";
        }
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-image: url('p3.png');
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            background-size: cover;
            background-attachment: fixed;
        }
        .form-container {
            width: 300px;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            background: white;
        }
        .form-container h2 {
            text-align: center;
            margin-bottom: 20px;
        }
        .form-container label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        .form-container input[type="text"],
        .form-container input[type="email"],
        .form-container input[type="password"],
        .form-container input[type="date"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }
        .form-container button {
            width: 100%;
            padding: 10px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        .form-container button:hover {
            background-color: #0056b3;
        }
        .notification {
            position: fixed;
            top: 0;
            width: 100%;
            text-align: center;
            background-color: #fff;
            padding: 10px;
            border-bottom: 2px solid #ccc;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        .notification p {
            color: red;
            font-weight: bold;
            margin: 0;
        }
    </style>
</head>
<body>
    <?php if ($notification): ?>
        <div class="notification">
            <p><?php echo $notification; ?></p>
        </div>
    <?php endif; ?>

    <div class="form-container">
        <?php if (!isset($_SESSION['step']) || $_SESSION['step'] == 1): ?>
            <h2>Forgot Password</h2>
            <form method="post">
                <label for="email_or_username">Email or Username:</label>
                <input type="text" id="email_or_username" name="email_or_username" required><br>
                <button type="submit">Submit</button>
            </form>
        <?php elseif ($_SESSION['step'] == 2): ?>
            <h2>Verify Information</h2>
            <form method="post">
                <label for="dob">Date of Birth:</label>
                <input type="date" id="dob" name="dob" required><br>
                <label for="hint1"><?php echo $_SESSION['selected_hints'][0]; ?></label>
                <input type="text" id="hint1" name="hint1" required><br>
                <label for="hint2"><?php echo $_SESSION['selected_hints'][1]; ?></label>
                <input type="text" id="hint2" name="hint2" required><br>
                <button type="submit">Submit</button></br>
            </form>
            <form method="post">
                <input type="hidden" name="action" value="back_to_step_1">
                <button type="submit">Back</button>
            </form>
        <?php elseif ($_SESSION['step'] == 3): ?>
            <h2>Reset Password</h2>
            <form method="post">
                <label for="new_password">New Password:</label>
                <input type="password" id="new_password" name="new_password" required
                    pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@$!%*?&#]).{8,}"
                    title="Must contain at least one number, one uppercase letter, one lowercase letter, one special character (@$!%*?&#), and be at least 8 characters long.">
                <label for="confirm_password">Confirm Password:</label>
                <input type="password" id="confirm_password" name="confirm_password" required><br>
                <button type="submit">Reset Password</button><br>
            </form>
            <form method="post">
                <input type="hidden" name="action" value="back_to_step_2">
                <button type="submit">Back</button>
            </form>
        <?php endif; ?>
    </div>
</body>
</html>
