<?php
session_start();

// Check if user is logged in and is admin
if (!isset($_SESSION['username']) || !isset($_SESSION['is_admin']) || !$_SESSION['is_admin']) {
    header('Location: login.php');
    exit();
}

// Establish database connection
$servername = "localhost";
$username = "root"; // default username for XAMPP
$password = ""; // default password for XAMPP
$database = "inventory"; // Replace with your database name
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch employee list from `data1` table
$sql = "SELECT id, first_name, last_name,employee_id, position, email,contact, company_name, company_email,dob,gender FROM data1";
$result = $conn->query($sql);
$employees = [];

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $employees[] = $row;
    }
}

// Close database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Inventory and Account Management</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            display: flex;
            height: 100vh;
            background-image:url('dash.png');
        }
        .sidebar {
            width: 250px;
            background-color: #004d40;
            color: #fff;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            overflow-y: auto;
            padding-top: 20px;
        }
        .sidebar h2 {
            text-align: center;
            margin-bottom: 20px;
        }
        .sidebar ul {
            list-style: none;
            padding: 0;
        }
        .sidebar ul li {
            padding: 10px 20px;
        }
        .sidebar ul li:hover {
            background-color: #00695c;
            cursor: pointer;
        }
.sidebar img {
            display: block;
            margin: 0 auto 10px;
            width: 100px;
            transition: transform 0.2s, background-color 0.2s;
        }
        .sidebar ul li a {
            color: #fff;
            text-decoration: none;
            display: block;
        }
        .content {
            margin-left: 250px;
            padding: 20px;
            flex: 1;
           
        }
        .content h1 {
            background-color: blueviolet;
            margin-top: 0;
            display: inline-block;
        }
        .table-container {
            margin-top: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            background:lightblue;
        }
        table, th, td {
            border: 1px solid black;
        }
        th, td {
            padding: 10px;
            text-align: left;
        }
        .hidden-details {
            display: none;
        }
        .action-icons {
            display: flex;
            justify-content: center;
        }
        .action-icons i {
            margin: 0 5px;
            cursor: pointer;
        }
    </style>
    <script>
        function showEmployeeDetails(id) {
            const rows = document.querySelectorAll('.employee-details');
            rows.forEach(row => {
                if (row.dataset.id === id) {
                    row.classList.toggle('hidden-details');
                }
            });
        }
    </script>
</head>
<body>
    <div class="sidebar">
    <img src="icon.png" alt="Admin"  width: 100px;
    transition: transform 0.2s, background-color 0.2s;>
        <h2>Admin</h2>
        <ul>
            <li><a href="">Dashboard</a></li>
            <li><a href="employee.php">Generatee ID</a></li>
            <li><a href="admin_issues.php">Issue</a></li>
            <li><a href="logout.php">Sign Out</a></li>
        </ul>
    </div>
    <div class="content">
        <h1>Employee List</h1>
        <div class="table-container">
            <table class="highlight">
                <thead>
                    <tr>
                        <th>Sr no</th>
                        <th>Emp Id</th>
                        <th>Full Name</th>
                        <th>email</th>
                        <th>Status</th>  
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($employees as $index => $employee): ?>
                        <tr onclick="showEmployeeDetails('<?php echo $employee['id']; ?>')">
                            <td><?php echo $index + 1; ?></td>
                            <td><?php echo $employee['employee_id']; ?></td>
                            <td><?php echo $employee['first_name'] . ' ' . $employee['last_name']; ?></td>
                            <td><?php echo $employee['email']; ?></td>
                            <td>ACTIVE</td>
                        </tr>
                        <tr class="employee-details hidden-details" data-id="<?php echo $employee['id']; ?>">
                            <<td colspan="5">
                                    <p>ID: <?php echo $employee['id']; ?></p>
                                    <p>Name: <?php echo $employee['first_name'] . ' ' . $employee['last_name']; ?></p>
                                    <p>dob: <?php echo $employee['dob']; ?></p>
                                    <p>Gender: <?php echo $employee['gender']; ?></p>
                                    <p>contact: <?php echo $employee['contact']; ?></p>
                                    <p>Company Email: <?php echo $employee['company_email']; ?></p>
                                    <p>Company Name: <?php echo $employee['company_name']; ?></p>
                                    <p>Email: <?php echo $employee['email']; ?></p>
                                </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
</body>
</html>