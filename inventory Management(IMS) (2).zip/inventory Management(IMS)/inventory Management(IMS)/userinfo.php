<?php
session_start();
if (!isset($_SESSION['username'])) {
    echo "<p>You are not logged in. Please login to view user information.</p>";
    exit();
}

$username = $_SESSION['username'];

// Establish database connection
$servername = "localhost";
$db_username = "root"; // default username for XAMPP
$db_password = ""; // default password for XAMPP
$database = "inventory"; // Replace with your database name
$conn = new mysqli($servername, $db_username, $db_password, $database);

if ($conn->connect_error) {
    echo "<p>Connection failed: " . $conn->connect_error . "</p>";
    exit();
}
// Fetch user data
$sql = "SELECT * FROM data1 WHERE username='$username'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();
    echo '<div class="user-info-container">';
    echo "<h2>User Information</h2>";
    echo "<ul>";
    foreach ($user as $key => $value) {
        if (!in_array($key, ['id','password', 'hint_answer1', 'hint_answer2','hint_answer3','hint_answer4','hint_answer5','created_at'])) {
            echo "<li><b>" . ucfirst($key) . "</b>: " . htmlspecialchars($value) . "</li>";
        }
    }
    echo "</ul>";
    echo '</div>';
} else {
    echo "<p>Error: User not found.</p>";
}

$conn->close();
?>
