<?php
$notification = "";

$servername = "localhost";
$username = "root";
$password = "";
$database = "inventory";
$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    $notification = "Connection failed: " . $conn->connect_error;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $employee_id = $_POST["employee_id"];
    $first_name = $_POST["First_name"];
    $last_name = $_POST["Last_name"];
    $username = $_POST["username"];
    $dob = $_POST["dob"];
    $gender = $_POST["gender"];
    $contact = $_POST["contact"];
    $email = $_POST["email"];
    $company_name = $_POST["company_name"];
    $company_email = $_POST["company_email"];
    $password = $_POST["password"];
    $confirm_password = $_POST["confirm_password"];
    $hint_answer1 = $_POST["hint_answer1"];
    $hint_answer2 = $_POST["hint_answer2"];
    $hint_answer3 = $_POST["hint_answer3"];
    $hint_answer4 = $_POST["hint_answer4"];
    $hint_answer5 = $_POST["hint_answer5"];

    if ($password != $confirm_password) {
        $notification = "Passwords do not match.";
    } else {
        $id_check_query = "SELECT * FROM generate_id WHERE employee_id='$employee_id' LIMIT 1";
        $id_result = $conn->query($id_check_query);
        if ($id_result->num_rows == 0) {
            $notification = "Invalid Employee ID.";
        } else {
            $email_check_query = "SELECT * FROM data1 WHERE email='$email' OR username='$username' LIMIT 1";
            $result = $conn->query($email_check_query);
            if ($result->num_rows > 0) {
                $notification = "Email or username already exists.";
            } else {
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                $sql = "INSERT INTO data1 (employee_id, first_name, last_name, username, gender, contact, email, password, company_name, dob, company_email, hint_answer1, hint_answer2, hint_answer3, hint_answer4, hint_answer5) 
                        VALUES ('$employee_id', '$first_name', '$last_name', '$username','$gender', '$contact', '$email', '$hashed_password', '$company_name', '$dob', '$company_email', '$hint_answer1', '$hint_answer2', '$hint_answer3', '$hint_answer4', '$hint_answer5')";
                if ($conn->query($sql) === TRUE) {
                    $notification = "Congrats! Sign up successful.";
                    header('Location: login.php');
                    exit;
                } else {
                    $notification = "Error: " . $sql . "<br>" . $conn->error;
                }
            }
        }
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-image: url('p3.png');
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            background-size: cover;
            background-attachment: fixed;
        }
        .signup-container {
            width: 300px;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            background: white;
        }
        .signup-container h2 {
            text-align: center;
            margin-bottom: 20px;
        }
        .signup-form label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        .signup-form input[type="text"],
        .signup-form input[type="email"],
        .signup-form input[type="password"],
        .signup-form input[type="date"],
        .signup-form input[type="radio"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }
        .signup-form button {
            width: 100%;
            padding: 10px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        .signup-form button:hover {
            background-color: #0056b3;
        }
        .signup-form span {
            font-size: 15px;
            color: rgb(255, 14, 14);
        }
        .notification {
            position: fixed;
            top: 0;
            width: 100%;
            text-align: center;
            background-color: #fff;
            padding: 10px;
            border-bottom: 2px solid #ccc;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        .notification p {
            color: red;
            font-weight: bold;
            margin: 0;
        }
        .gender-options {
            display: flex;
            justify-content: space-between;
        }
    </style>
</head>
<body>
    <?php if ($notification): ?>
        <div class="notification">
            <p><?php echo $notification; ?></p>
        </div>
    <?php endif; ?>

    <div class="signup-container">
        <h2>Sign Up</h2>
        <form class="signup-form" method="post">
            <label for="employee_id">Employee ID:</label>
            <input type="text" id="employee_id" name="employee_id" required><br>
            <label for="First_name">First Name:</label>
            <input type="text" id="First_name" name="First_name" required><br>
            <label for="Last_name">Last Name:</label>
            <input type="text" id="Last_name" name="Last_name" required><br>
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" required><br>
            <label for="dob">Date of Birth:</label>
            <input type="date" id="dob" name="dob" required><br>
            <label for="gender">Gender:</label>
            <div class="gender-options">
                <label><input type="radio" id="male" name="gender" value="Male" required> Male</label>
                <label><input type="radio" id="female" name="gender" value="Female" required> Female</label>
                <label><input type="radio" id="other" name="gender" value="Other" required> Other</label>
            </div>
            <label for="contact">Contact:</label>
            <input type="text" id="contact" name="contact" required><br>
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required><br>
            <label for="company_name">Company Name:</label>
            <input type="text" id="company_name" name="company_name" required><br>
            <label for="company_email">Company Email:</label>
            <input type="email" id="company_email" name="company_email" required><br>
            <span>Password must be at least 8 characters long, contain at least one uppercase letter, one lowercase letter, one number, and one special character.</span><br>
            <label for="password">Password:</label><br>
            <input type="password" id="password" name="password" required
                   pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@$!%*?&#]).{8,}"
                   title="Must contain at least one number, one uppercase letter, one lowercase letter, one special character (@$!%*?&#), and be at least 8 characters long.">
            <br><br>
            <label for="confirm_password">Confirm Password:</label>
            <input type="password" id="confirm_password" name="confirm_password" required><br>
            <span>Note !! Below question are for needed at the time of resetting password in case of forget password.</span>
            <label for="hint_answer1">What is your mother DOB ?</label>
            <input type="text" id="hint_answer1" name="hint_answer1" required><br>
            <label for="hint_answer2">Which is your childhood bestfriend ?</label>
            <input type="text" id="hint_answer2" name="hint_answer2" required><br>
            <label for="hint_answer3">Who is your favourite superhero?</label>
            <input type="text" id="hint_answer3" name="hint_answer3" required><br>
            <label for="hint_answer4">Which is your favourite webseries?</label>
            <input type="text" id="hint_answer4" name="hint_answer4" required><br>
            <label for="hint_answer5">Which animal you prefer as a pet much ?</label>
            <input type="text" id="hint_answer5" name="hint_answer5" required><br>
            <button type="submit">Sign Up</button>
        </form>
        <a href="login.php">Already have an account? Log in</a>
    </div>

    <script>
        document.querySelector('form').addEventListener('submit', function(event) {
            const password = document.getElementById('password').value;
            const confirmPassword = document.getElementById('confirm_password').value;
            const passwordPattern = /(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@$!%*?&#]).{8,}/;

            if (!passwordPattern.test(password)) {
                alert('Password does not meet the requirements.');
                event.preventDefault();
            } else if (password !== confirmPassword) {
                alert('Passwords do not match.');
                event.preventDefault();
            }
        });
    </script>
</body>
</html>
