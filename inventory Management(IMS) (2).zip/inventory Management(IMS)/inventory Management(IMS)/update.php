<?php
session_start();
if (!isset($_SESSION['username'])) {
    echo "<p>You are not logged in. Please login to update your information.</p>";
    exit();
}

$username = $_SESSION['username'];

// Establish database connection
$servername = "localhost";
$db_username = "root"; // default username for XAMPP
$db_password = ""; // default password for XAMPP
$database = "inventory"; // Replace with your database name
$conn = new mysqli($servername, $db_username, $db_password, $database);

if ($conn->connect_error) {
    echo "<p>Connection failed: " . $conn->connect_error . "</p>";
    exit();
}

// Handle form submission for updating user information
$notification = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $contact = $_POST['contact'];
    $gender = $_POST['gender'];

    $sql = "UPDATE data1 SET email=?, contact=?, gender=? WHERE username=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssss", $email, $contact, $gender, $username);

    if ($stmt->execute()) {
        $notification = "Information updated successfully.";
    } else {
        $notification = "Error updating information: " . $stmt->error;
    }
    $stmt->close();
}

// Fetch user data
$sql = "SELECT email, contact, gender FROM data1 WHERE username=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();
} else {
    echo "<p>Error: User not found.</p>";
    $stmt->close();
    $conn->close();
    exit();
}

$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Information</title>
    <link rel="stylesheet" href="body.css">
    <style>
        .form-container {
            width: 300px;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            margin: 0 auto;
            margin-top: 50px;
        }
        h2 {
            text-align: center;
            margin-bottom: 20px;
        }
        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        input[type="text"], input[type="email"], input[type="tel"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }
        .gender-options {
            margin-bottom: 10px;
        }
        .gender-options label {
            display: inline-block;
            margin-right: 10px;
        }
        button {
            width: 100%;
            padding: 10px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="form-container">
        <h2>Update Information</h2>
        <?php if ($notification): ?>
            <p><?php echo $notification; ?></p>
        <?php endif; ?>
        <form method="post">
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>"><br>
            <label for="contact">Contact:</label>
            <input type="tel" id="contact" name="contact" value="<?php echo htmlspecialchars($user['contact']); ?>"><br>
            <label for="gender">Gender:</label>
            <div class="gender-options">
                <label><input type="radio" id="male" name="gender" value="male" <?php if ($user['gender'] == 'male') echo 'checked'; ?> > Male</label>
                <label><input type="radio" id="female" name="gender" value="female" <?php if ($user['gender'] == 'female') echo 'checked'; ?>> Female</label>
                <label><input type="radio" id="other" name="gender" value="other" <?php if ($user['gender'] == 'other') echo 'checked'; ?> > Other</label>
            </div>
            <button type="submit">Update</button>
        </form>
    </div>
</body>
</html>
