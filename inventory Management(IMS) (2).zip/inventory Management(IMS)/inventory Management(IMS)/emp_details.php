<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "inventory";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $employee_id = $_POST["employee_id"];

    // Fetch employee details
    $sql = "SELECT employee_id, first_name, last_name, contact, email FROM data1 WHERE employee_id='$employee_id'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $employee = $result->fetch_assoc();
        echo "Employee ID: " . $employee['employee_id'] . "<br>";
        echo "Name: " . $employee['first_name'] . " " . $employee['last_name'] . "<br>";
        echo "Contact: " . $employee['contact'] . "<br>";
        echo "Email: " . $employee['email'] . "<br>";
    } else {
        echo "No employee found.";
    }
}

$conn->close();
?>
