<?php
session_start();
if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit();
}

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "inventory";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Mark all notifications as read
if (isset($_GET['mark_as_read'])) {
    $mark_as_read_sql = "UPDATE notifications SET is_read = 1 WHERE is_read = 0";
    $conn->query($mark_as_read_sql);
}

// Fetch notifications
$notifications_sql = "SELECT * FROM notifications ORDER BY created_at DESC";
$notifications_result = $conn->query($notifications_sql);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notifications</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: gainsboro;
            color: black;
            margin: 0;
            padding: 0;
        }
        .content {
            margin: 20px;
            background-color: #222;
            padding: 20px;
            border-radius: 8px;
            color: white;
        }
        .notification {
            background-color: #ff5722;
            padding: 10px;
            border-radius: 4px;
            margin-bottom: 10px;
        }
        .mark-as-read {
            margin: 20px 0;
            text-align: right;
        }
        .mark-as-read button {
            padding: 10px 20px;
            background-color: #007BFF;
            color: white;
            border: none;
            cursor: pointer;
            border-radius: 4px;
        }
    </style>
</head>
<body>
    <div class="content">
        <h1>Notifications</h1>
        <div class="mark-as-read">
            <a href="?mark_as_read=1"><button>Mark all as read</button></a>
        </div>
        <?php
        if ($notifications_result->num_rows > 0) {
            while ($row = $notifications_result->fetch_assoc()) {
                echo "<div class='notification'>" . $row['message'] . " <small>(" . $row['created_at'] . ")</small></div>";
            }
        } else {
            echo "<p>No notifications</p>";
        }
        ?>
    </div>
</body>
</html>
<?php
$conn->close();
?>
