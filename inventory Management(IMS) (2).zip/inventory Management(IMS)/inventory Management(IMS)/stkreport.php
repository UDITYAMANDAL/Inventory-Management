<?php
session_start();
if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit();
}

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "inventory";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle search query
$search_query = isset($_GET['search']) ? $_GET['search'] : '';

// Fetch stock data
$stock_sql = "SELECT * FROM stock WHERE prodid LIKE '%$search_query%' OR prodname LIKE '%$search_query%'";
$stock_result = $conn->query($stock_sql);

// Fetch stockout data
$stockout_sql = "SELECT * FROM stockout WHERE prodid LIKE '%$search_query%' OR prodname LIKE '%$search_query%'";
$stockout_result = $conn->query($stockout_sql);

// Process data
$stock_data = [];

if ($stock_result->num_rows > 0) {
    while ($row = $stock_result->fetch_assoc()) {
        $prodid = $row['prodid'];
        if (!isset($stock_data[$prodid])) {
            $stock_data[$prodid] = [
                'prodid' => $row['prodid'],
                'prodname' => $row['prodname'],
                'prodtype' => $row['prodtype'],
                'prodrate' => $row['prodrate'],
                'prodquantity' => $row['prodquantity'],
                'prodimage' => $row['prodimage'],
                'stock' => $row['prodquantity'],
                'stockout' => 0,
                'remaining' => $row['prodquantity']
            ];
        } else {
            $stock_data[$prodid]['stock'] += $row['prodquantity'];
            $stock_data[$prodid]['remaining'] += $row['prodquantity'];
        }
    }
}

if ($stockout_result->num_rows > 0) {
    while ($row = $stockout_result->fetch_assoc()) {
        $prodid = $row['prodid'];
        if (isset($stock_data[$prodid])) {
            $stock_data[$prodid]['stockout'] += $row['prodquantity'];
            $stock_data[$prodid]['remaining'] -= $row['prodquantity'];
        } else {
            $stock_data[$prodid] = [
                'prodid' => $row['prodid'],
                'prodname' => $row['prodname'],
                'prodtype' => $row['prodtype'],
                'prodrate' => $row['prodrate'],
                'prodquantity' => 0,
                'prodimage' => $row['prodimage'],
                'stock' => 0,
                'stockout' => $row['prodquantity'],
                'remaining' => -$row['prodquantity']
            ];
        }
    }
}

$current_time = date("Y-m-d H:i:s");

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stock Report</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: gainsboro;
            background-image: url('dash.png');
            color: white;
            margin: 0;
            padding: 0;
        }
        .top-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px;
            background-color: #3f51b5;
            position: relative;
        }
        .top-bar form {
            margin: 0;
        }
        .top-bar .search-bar {
            flex-grow: 1;
            display: flex;
            justify-content: center;
        }
        .top-bar input {
            padding: 10px;
            font-size: 16px;
        }
        .top-bar button {
            padding: 10px;
            background-color: #007BFF;
            color: white;
            border: none;
            cursor: pointer;
        }
        .top-bar .actions {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .top-bar input {
            padding: 10px;
            font-size: 16px;
        }
        .top-bar button {
            padding: 10px;
            background-color: #007BFF;
            color: white;
            border: none;
            cursor: pointer;
        }
        .top-bar .print-btn {
            background-color: #007BFF;
        }
        .content {
            margin: 20px;
            background-color: #222;
            padding: 20px;
            border-radius: 8px;
        }
        h1{
            text-align: center;
            color: #fff;
        }
         h2 {
            color: #fff;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            padding: 12px;
            border: 1px solid #ddd;
            text-align: left;
            color: #fff;
        }
        th {
            background-color: #3f51b5;
        }
        td {
            background-color: #333;
        }
        th:nth-child(1) { background-color: #4CAF50; }
        th:nth-child(2) { background-color: #2196F3; }
        th:nth-child(3) { background-color: #FFC107; }
        th:nth-child(4) { background-color: #E91E63; }
        th:nth-child(5) { background-color: #9C27B0; }
        th:nth-child(6) { background-color: #FF5722; }
        th:nth-child(7) { background-color: #795548; }
        th:nth-child(8) { background-color: #607D8B; }
        .pagination {
            display: flex;
            justify-content: center;
            margin-top: 20px;
        }
        .pagination a {
            padding: 10px;
            margin: 0 5px;
            background-color: #3f51b5;
            color: white;
            text-decoration: none;
            font-weight: bold;
            border-radius: 4px;
        }
        .pagination a.active {
            background-color: #ff5722;
        }
        .pagination a:visited {
            color: white;
        }
        .pagination .prev, .pagination .next {
            font-size: 18px;
        }
        .timestamp {
            text-align: right;
            margin-top: 10px;
        }
        .user-menu {
            display: flex;
            align-items: center;
            justify-content: flex-end;
            position: relative;
        }
        .user-icon img {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            cursor: pointer;
        }

        .user-dropdown {
            display: none;
            position: absolute;
            top: 50px;
            right: 0;
            color: black;
            background-color: #fff;
            border: 1px solid #ccc;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            z-index: 1;
        }

        .user-dropdown.show {
            display: block;
        }

        .user-dropdown a {
            display: block;
            padding: 10px;
            text-decoration: none;
            color: #333;
        }

        .user-dropdown a:hover {
            background-color: #000000;
        }
    </style>
    <script>
        function printReport() {
            window.print();
        }

        function showDetails(prodid, prodname) {
            window.location.href = 'product_details.php?prodid=' + prodid + '&prodname=' + prodname;
        }
    </script>
</head>
<body>
<div class="user-menu">
                    <div class="user-icon">
                        <img src="icon.png" alt="User Icon">
                    </div>
                    <div class="user-dropdown">
                        <a href="logout.php">Logout</a>
                    </div>
                </div>
    <div class="content">
    <h1>Stock Report</h1>
    <div class="timestamp">
            <strong>Date and Time:</strong> <?php echo $current_time; ?>
        </div>  
        <div class="top-bar">
        <button onclick="location.href='dashboard.php'">Home</button>
        <div class="search-bar">
            <form method="GET" action="">
                <input type="text" name="search" placeholder="Search by Product ID or Name" value="<?php echo $search_query; ?>">
                <button type="submit">Search</button>
            </form>
        </div>
        <div class="print-button">
            <button onclick="printReport()">Print Report</button>
        </div>
        
            </div>
        <table>
            <tr>
                <th>Product ID</th>
                <th>Product Name</th>
                <th>Product Type</th>
                <th>Product Rate</th>
                <th>Stock In</th>
                <th>Stock Out</th>
                <th>Remaining Stock</th>
                <th>Product Image</th>
            </tr>
            <?php
            if (!empty($stock_data)) {
                foreach ($stock_data as $data) {
                    echo "<tr>
                            <td><a href='' onclick='showDetails(\"" . $data['prodid'] . "\", \"" . $data['prodname'] . "\")'>" . $data['prodid'] . "</a></td>
                            <td><a href='#' onclick='showDetails(\"" . $data['prodid'] . "\", \"" . $data['prodname'] . "\")'>" . $data['prodname'] . "</a></td>
                            <td>" . $data['prodtype'] . "</td>
                            <td>" . $data['prodrate'] . "</td>
                            <td>" . $data['stock'] . "</td>
                            <td>" . $data['stockout'] . "</td>
                            <td>" . $data['remaining'] . "</td>
                            <td><img src='" . $data['prodimage'] . "' alt='Product Image' width='50'></td>
                          </tr>";
                }
            } else {
                echo "<tr><td colspan='8'>No records found</td></tr>";
            }
            ?>
        </table>
    </div>
    <script>
        document.querySelector('.user-icon').addEventListener('click', function() {
            document.querySelector('.user-dropdown').classList.toggle('show');
        });
    </script>
</body>
</html>

<?php
$conn->close();
?>
