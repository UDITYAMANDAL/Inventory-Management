<?php
session_start();
if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit();
}

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "inventory";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle search query
$search_query = isset($_GET['search']) ? $_GET['search'] : '';

// Handle form submission to update stock and stockout limits
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $prodid = $_POST['prodid'];
    $stock_limit = $_POST['stock_limit'];
    $stockout_limit = $_POST['stockout_limit'];

    // Update stock limit
    $update_stock_limit_sql = "UPDATE stock SET stock_limit = ? WHERE prodid = ?";
    $stmt = $conn->prepare($update_stock_limit_sql);
    $stmt->bind_param("is", $stock_limit, $prodid);
    $stmt->execute();

    // Update stockout limit
    $update_stockout_limit_sql = "UPDATE stockout SET stockout_limit = ? WHERE prodid = ?";
    $stmt = $conn->prepare($update_stockout_limit_sql);
    $stmt->bind_param("is", $stockout_limit, $prodid);
    $stmt->execute();
}

// Pagination settings
$limit = 10;
$page = isset($_GET['page']) ? $_GET['page'] : 1;
$offset = ($page - 1) * $limit;

// Fetch stock data with pagination
$stock_sql = "SELECT * FROM stock WHERE prodid LIKE '%$search_query%' OR prodname LIKE '%$search_query%' LIMIT $limit OFFSET $offset";
$stock_result = $conn->query($stock_sql);

// Fetch total number of records
$total_records_sql = "SELECT COUNT(*) as count FROM stock WHERE prodid LIKE '%$search_query%' OR prodname LIKE '%$search_query%'";
$total_records_result = $conn->query($total_records_sql);
$total_records = $total_records_result->fetch_assoc()['count'];
$total_pages = ceil($total_records / $limit);

// Fetch stockout data
$stockout_sql = "SELECT * FROM stockout WHERE prodid LIKE '%$search_query%' OR prodname LIKE '%$search_query%' LIMIT $limit OFFSET $offset";
$stockout_result = $conn->query($stockout_sql);

// Process data
$stock_data = [];
$notifications = [];

if ($stock_result->num_rows > 0) {
    while ($row = $stock_result->fetch_assoc()) {
        $prodid = $row['prodid'];
        if (!isset($stock_data[$prodid])) {
            $stock_data[$prodid] = [
                'prodid' => $row['prodid'],
                'prodname' => $row['prodname'],
                'prodtype' => $row['prodtype'],
                'prodrate' => $row['prodrate'],
                'prodquantity' => $row['prodquantity'],
                'prodimage' => $row['prodimage'],
                'stock' => $row['prodquantity'],
                'stock_limit' => $row['stock_limit'],
                'stockout' => 0,
                'stockout_limit' => 0
            ];
        } else {
            $stock_data[$prodid]['stock'] += $row['prodquantity'];
        }

        if ($stock_data[$prodid]['stock'] >= $row['stock_limit']) {
            $notifications[] = "Stock for product ID " . $prodid . " has reached the stock limit.";
        }
    }
}

if ($stockout_result->num_rows > 0) {
    while ($row = $stockout_result->fetch_assoc()) {
        $prodid = $row['prodid'];
        if (isset($stock_data[$prodid])) {
            $stock_data[$prodid]['stockout'] += $row['prodquantity'];
            $stock_data[$prodid]['stockout_limit'] = $row['stockout_limit'];
        } else {
            $stock_data[$prodid] = [
                'prodid' => $row['prodid'],
                'prodname' => $row['prodname'],
                'prodtype' => $row['prodtype'],
                'prodrate' => $row['prodrate'],
                'prodquantity' => 0,
                'prodimage' => $row['prodimage'],
                'stock' => 0,
                'stock_limit' => 0,
                'stockout' => $row['prodquantity'],
                'stockout_limit' => $row['stockout_limit']
            ];
        }

        if ($stock_data[$prodid]['stockout'] >= $row['stockout_limit']) {
            $notifications[] = "Stockout for product ID " . $prodid . " has reached the stockout limit.";
        }
    }
}

$current_time = date("Y-m-d H:i:s");

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stock Report</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: gainsboro;
            color: white;
            margin: 0;
            padding: 0;
            background-image: url('dash.png');
        }
        .top-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px;
            background-color: #3f51b5;
        }
        .search-bar {
            flex-grow: 1;
            display: flex;
            justify-content: center;
        }
        .search-bar input {
            padding: 10px;
            font-size: 16px;
            width: 300px;
        }
        .search-bar button {
            padding: 10px;
            background-color: #007BFF;
            color: white;
            border: none;
            cursor: pointer;
        }

        .top-bar input {
            padding: 10px;
            font-size: 16px;
            margin-right: 10px;
        }

        .top-bar button {
            padding: 10px;
            background-color: #007BFF;
            color: white;
            border: none;
            cursor: pointer;
            margin-left: 10px;
        }

        .content {
            margin: 20px;
            background-color: #222;
            padding: 20px;
            border-radius: 8px;
        }
        h1, h2 {
            color: #fff;
            text-align: center;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            padding: 12px;
            border: 1px solid #ddd;
            text-align: left;
            color: #fff;
        }
        th {
            background-color: #3f51b5;
        }
        td {
            background-color: #333;
        }
        th:nth-child(1) { background-color: #4CAF50; }
        th:nth-child(2) { background-color: #2196F3; }
        th:nth-child(3) { background-color: #FFC107; }
        th:nth-child(4) { background-color: #E91E63; }
        th:nth-child(5) { background-color: #9C27B0; }
        th:nth-child(6) { background-color: #FF5722; }
        th:nth-child(7) { background-color: #795548; }
        th:nth-child(8) { background-color: #607D8B; }
        .pagination {
            display: flex;
            justify-content: center;
            margin-top: 20px;
        }
        .pagination a {
            padding: 10px;
            margin: 0 5px;
            background-color: #3f51b5;
            color: white;
            text-decoration: none;
            font-weight: bold;
            border-radius: 4px;
        }
        .pagination a.active {
            background-color: #ff5722;
        }
        .pagination a:visited {
            color: white;
        }
        .pagination .prev, .pagination .next {
            font-size: 18px;
        }

        .timestamp {
            text-align: right;
            margin-top: 10px;
        }
        .form-container {
            margin: 20px 0;
        }
        .form-container form {
            display: flex;
            flex-direction: column;
        }
        .form-container input, .form-container button {
            padding: 10px;
            margin-bottom: 10px;
            border: none;
            border-radius: 4px;
        }
        .form-container input {
            width: 300px;
        }
        .form-container button {
            background-color: #007BFF;
            color: white;
            cursor: pointer;
        }
        .form-container .stock-limit-form {
            margin-bottom: 20px;
        }
        .user-menu {
            display: flex;
            justify-content: flex-end;
            align-items: center;
            position: relative;
            padding: 15px;
            gap: 15px;
        }
        .user-icon img {
            width: 50px;
            height: 50px;
            border-radius: 50%;
        }

        .user-dropdown {
            display: none;
            position: absolute;
            top: 60px;
            right: 0;
            background-color: white;
            border: 1px solid #ccc;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            z-index: 1;
        }

        .user-dropdown.show {
            display: block;
        }

        .user-dropdown a {
            display: block;
            padding: 10px;
            text-decoration: none;
            color: #333;
        }

        .user-dropdown a:hover {
            background-color: #000000;
        }
        .notification {
            margin: 20px 0;
            padding: 10px;
            border-radius: 4px;
            background-color: grey;
            color: white;
            display: none;
        }
        .notification-count {
            position: absolute;
            top: -1px;
            right: -1px;
            background-color: red;
            color: white;
            border-radius: 30%;
            padding: 2px 6px;
            font-size: 18px;
        }
    </style>
    <script>
         document.addEventListener('DOMContentLoaded', function () {
            document.getElementById('notification-icon').addEventListener('click', function () {
                var notificationsContent = document.getElementById('notifications-content');
                if (notificationsContent.style.display === 'none') {
                    notificationsContent.style.display = 'block';
                } else {
                    notificationsContent.style.display = 'none';
                }
            });
        });

        function printReport() {
            window.print();
        }

        function showDetails(prodid, prodname) {
            window.location.href = 'product_details.php?prodid=' + prodid + '&prodname=' + prodname;
        }

        function toggleSetLimitForm() {
            var form = document.getElementById('setLimitForm');
            form.style.display = form.style.display === 'none' ? 'block' : 'none';
        }
        function toggleUserMenu() {
            var dropdown = document.querySelector('.user-dropdown');
            dropdown.classList.toggle('show');
        }

        document.addEventListener('DOMContentLoaded', function () {
            var userIcon = document.querySelector('.user-icon img');
            userIcon.addEventListener('click', toggleUserMenu);
        });
    </script>
</head>
<body>
<div class="user-menu">
<div class="user-icon">
        <img src="icon.png" alt="User Icon">
    </div>
    <div class="user-dropdown">
        <a href="userinfo.php">Profile</a>
        <a href="logout.php">Logout</a>
    </div>
<div id="notification-icon" style="cursor: pointer;">
            <img src="notification.png" alt="Notifications" width="40" height="40">
            <?php if (count($notifications) > 0): ?>
                    <div class="notification-count"><?php echo count($notifications); ?></div>
                <?php endif; ?>
        </div>
    </div>
    <div id="notifications-content" class="notification">
        <?php if (count($notifications) > 0): ?>
            <ul>
                <?php foreach ($notifications as $notification): ?>
                    <li><?php echo $notification; ?></li>
                <?php endforeach; ?>
            </ul>
        <?php else: ?>
            <p>No notifications</p>
        <?php endif; ?>
    </div>    
</div>
<div class="content">
<div class="timestamp">
    <strong>Date and Time:</strong> <?php echo $current_time; ?>
</div>
<h1>Stock Limit Management</h1>

<div class="top-bar">
    <button onclick="location.href='dashboard.php'">Home</button>
    <form method="GET" action="limit.php" class="search-bar">
        <input type="text" name="search" value="<?php echo htmlspecialchars($search_query); ?>" placeholder="Search...">
        <button type="submit">Search</button>
    </form>
    <button id="printBtn" class="btn print" onclick="window.print()">Print</button>
    <button onclick="toggleSetLimitForm()">Set Limit</button>
</div>

<div id="setLimitForm" class="form-container" style="display:none;">
    <h2>Set Stock and Stockout Limits</h2>
    <form method="POST" action="">
        <input type="text" name="prodid" placeholder="Product ID" required>
        <input type="number" name="stock_limit" placeholder="Stock Limit" required>
        <input type="number" name="stockout_limit" placeholder="Stockout Limit" required>
        <button type="submit">Save</button>
        <button type="button" onclick="toggleSetLimitForm()">Cancel</button>
    </form>
</div>

<table>
    <tr>
        <th>Product ID</th>
        <th>Product Name</th>
        <th>Product Type</th>
        <th>Product Rate</th>
        <th>Stock In</th>
        <th>Stock Limit</th>
        <th>Stock Out</th>
        <th>Stockout Limit</th>
        <th>Product Image</th>
    </tr>
    <?php
    if (!empty($stock_data)) {
        foreach ($stock_data as $data) {
            echo "<tr>
                    <td>" . $data['prodid'] . "</td>
                    <td>" . $data['prodname'] . "</td>
                    <td>" . $data['prodtype'] . "</td>
                    <td>" . $data['prodrate'] . "</td>
                    <td>" . $data['stock'] . "</td>
                    <td>" . $data['stock_limit'] . "</td>
                    <td>" . $data['stockout'] . "</td>
                    <td>" . $data['stockout_limit'] . "</td>
                    <td><img src='" . $data['prodimage'] . "' alt='Product Image' width='50'></td>
                  </tr>";
        }
    } else {
        echo "<tr><td colspan='9'>No records found</td></tr>";
    }
    ?>
</table>

<div class="pagination">
    <?php if($page > 1): ?>
        <a href="?page=<?php echo $page - 1; ?>" class="prev">&laquo; Previous</a>
    <?php endif; ?>

    <?php for($i = 1; $i <= $total_pages; $i++): ?>
        <a href="?page=<?php echo $i; ?>" class="<?php if($i == $page) echo 'active'; ?>"><?php echo $i; ?></a>
    <?php endfor; ?>

    <?php if($page < $total_pages): ?>
        <a href="?page=<?php echo $page + 1; ?>" class="next">Next &raquo;</a>
    <?php endif; ?>
</div>

</div>
</body>
</html>

<?php
$conn->close();
?>