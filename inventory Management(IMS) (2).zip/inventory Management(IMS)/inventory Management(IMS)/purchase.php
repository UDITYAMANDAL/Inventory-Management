<?php
session_start();
if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit();
}

$servername = "localhost";
$username = "root";
$password = "";	
$dbname = "inventory";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize undo and redo stacks
if (!isset($_SESSION['undoPurchase'])) {
    $_SESSION['undoPurchase'] = [];
}
if (!isset($_SESSION['redoPurchase'])) {
    $_SESSION['redoPurchase'] = [];
}

$undoStack = $_SESSION['undoPurchase'];
$redoStack = $_SESSION['redoPurchase'];

function saveState($conn) {
    global $undoStack;
    $result = $conn->query("SELECT * FROM purchase ORDER BY id ASC");
    $state = [];
    while ($row = $result->fetch_assoc()) {
        $state[] = $row;
    }
    array_push($undoStack, $state);
    if (count($undoStack) > 5) {
        array_shift($undoStack);
    }
    $_SESSION['undoPurchase'] = $undoStack;
}

function restoreState($conn, $state) {
    $conn->query("DELETE FROM purchase");
    foreach ($state as $row) {
        $conn->query("INSERT INTO purchase (id, date, name, address, contact, product_id, product_name, quantity, rate, discount, gst, cgst, total)
        VALUES ({$row['id']}, '{$row['date']}', '{$row['name']}', '{$row['address']}', '{$row['contact']}', '{$row['product_id']}', '{$row['product_name']}', '{$row['quantity']}', '{$row['rate']}', '{$row['discount']}', '{$row['gst']}', '{$row['cgst']}', '{$row['total']}')");
    }
}

// Handle form submission for adding/updating stock
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    saveState($conn);

    $id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
    $date = $_POST['date'];
    $name = $_POST['name'];
    $address = $_POST['address'];
    $contact = $_POST['contact'];
    $product_id = $_POST['product_id'];
    $product_name = $_POST['product_name'];
    $quantity = $_POST['quantity'];
    $rate = $_POST['rate'];
    $discount = $_POST['discount'];
    $gst = $_POST['gst'];
    $cgst = $_POST['cgst'];
    $total = $_POST['total'];

    if ($id > 0) {
        // Update existing record
        $sql = "UPDATE purchase SET 
                date='$date', 
                name='$name', 
                address='$address', 
                contact='$contact', 
                product_id='$product_id', 
                product_name='$product_name', 
                quantity='$quantity', 
                rate='$rate', 
                discount='$discount', 
                gst='$gst', 
                cgst='$cgst', 
                total='$total'
                WHERE id=$id";
    } else {
        // Insert new record
        $sql = "INSERT INTO purchase (date, name, address, contact, product_id, product_name, quantity, rate, discount, gst, cgst, total)
                VALUES ('$date', '$name', '$address', '$contact', '$product_id', '$product_name', '$quantity', '$rate', '$discount', '$gst', '$cgst', '$total')";
    }

    if ($conn->query($sql) === TRUE) {
        echo "Record saved successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    // Reset the auto increment id
    $conn->query("ALTER TABLE purchase AUTO_INCREMENT = 1");

    // End the session for add product
    unset($_SESSION['add_product']);
    header('Location: purchase.php');
    exit();
}

// Handle delete
if (isset($_GET['delete'])) {
    saveState($conn);
    $id = (int)$_GET['delete'];
    $conn->query("DELETE FROM purchase WHERE id=$id");
    $conn->query("ALTER TABLE purchase AUTO_INCREMENT = 1");
}

// Handle search
$search = '';
if (isset($_GET['search'])) {
    $search = $conn->real_escape_string($_GET['search']);
}

// Fetch record to edit
$edit_id = 0;
$edit_record = null;
if (isset($_GET['edit'])) {
    $edit_id = (int)$_GET['edit'];
    $result = $conn->query("SELECT * FROM purchase WHERE id=$edit_id");
    $edit_record = $result->fetch_assoc();
    $_SESSION['add_product'] = true; // Ensure form is displayed
}

// Start a session for add product when 'add' is set
if (isset($_GET['add'])) {
    $_SESSION['add_product'] = true;
}

// End the session for add product when 'cancel' is set
if (isset($_GET['cancel'])) {
    unset($_SESSION['add_product']);
    header('Location: purchase.php');
    exit();
}

// Handle undo
if (isset($_GET['undo']) && !empty($undoStack)) {
    $redoStack[] = array_pop($undoStack);
    $state = end($undoStack);
    restoreState($conn, $state);
    $_SESSION['undoPurchase'] = $undoStack;
    $_SESSION['redoPurchase'] = $redoStack;
    header('Location: purchase.php');
    exit();
}

// Handle redo
if (isset($_GET['redo']) && !empty($redoStack)) {
    $undoStack[] = array_pop($redoStack);
    $state = end($redoStack);
    restoreState($conn, $state);
    $_SESSION['undoPurchase'] = $undoStack;
    $_SESSION['redoPurchase'] = $redoStack;
    header('Location: purchase.php');
    exit();
}

// Pagination logic
$records_per_page = 10;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$start_from = ($page - 1) * $records_per_page;
$sql_count = "SELECT COUNT(*) FROM purchase";
if ($search) {
    $sql_count .= " WHERE name LIKE '%$search%' OR address LIKE '%$search%' OR contact LIKE '%$search%' OR product_name LIKE '%$search%' OR product_id LIKE '%$search%'";
}
$total_records_result = $conn->query($sql_count);
$total_records = $total_records_result->fetch_array()[0];
$total_pages = ceil($total_records / $records_per_page);

$sql = "SELECT * FROM purchase";
if ($search) {
    $sql .= " WHERE name LIKE '%$search%' OR address LIKE '%$search%' OR contact LIKE '%$search%' OR product_name LIKE '%$search%' OR product_id LIKE '%$search%'";
}
$sql .= " ORDER BY id ASC LIMIT $start_from, $records_per_page";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Purchase</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background: url('dash.png') no-repeat center center fixed;
            background-size: cover;
            color: white;
        }
        .top-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px;
            background-color: #3f51b5;
            position: relative;
        }
        .top-bar form {
            margin: 0;
        }
        .top-bar .search-bar {
            flex-grow: 1;
            display: flex;
            justify-content: center;
        }
        .top-bar input {
            padding: 10px;
            font-size: 16px;
        }
        .top-bar button {
            padding: 10px;
            background-color: #007BFF;
            color: white;
            border: none;
            cursor: pointer;
        }
        .top-bar .actions {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .top-bar input {
            padding: 10px;
            font-size: 16px;
        }
        .top-bar button {
            padding: 10px;
            background-color: #007BFF;
            color: white;
            border: none;
            cursor: pointer;
        }
        .top-bar .print-btn {
            background-color: #007BFF;
        }
        .content {
            margin: 20px;
            background-color: #222;
            padding: 20px;
            border-radius: 8px;
        }
        h1 {
            color: #fff;
            text-align:center;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            padding: 12px;
            border: 1px solid #ddd;
            text-align: left;
            color: white;
        }
        th {
            background-color: #444;
            color: #fff;
        }
        .form-section {
            margin-top: 20px;
        }
        #newBuyerForm {
            display: <?php echo isset($_SESSION['add_product']) ? 'block' : 'none'; ?>;
        }
        #newBuyerForm input {
            margin-bottom: 20px;
            padding: 10px;
            font-size: 16px;
            flex: 1 1 30%;
            margin-right: 10px;
        }
        #newBuyerForm button {
            padding: 10px;
            margin-right: 10px;
            border: none;
            cursor: pointer;
            flex: 1 1 20%;
        }
        .btn.save {
            background-color: green;
            color: white;
        }
        .btn.cancel {
            background-color: red;
            color: white;
        }
        .btn.edit {
            background-color: green;
            color: white;
        }
        .btn.delete {
            background-color: red;
            color: white;
        }
        .pagination {
            margin: 20px 0;
            text-align: center;
        }
        .pagination a {
            color: white;
            padding: 10px;
            text-decoration: none;
            background-color: #007BFF;
            margin: 0 5px;
            border-radius: 5px;
        }
        .pagination a.active {
            background-color: #0056b3;
        }
        .no-records {
            color: #ff0000;
            text-align: center;
            margin-top: 20px;
        }
        .user-menu {
            display: flex;
            align-items: center;
            justify-content: flex-end;
            position: relative;
        }
        .user-icon img {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            cursor: pointer;
        }

        .user-dropdown {
            display: none;
            position: absolute;
            top: 50px;
            right: 0;
            color: black;
            background-color: #fff;
            border: 1px solid #ccc;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            z-index: 1;
        }

        .user-dropdown.show {
            display: block;
        }

        .user-dropdown a {
            display: block;
            padding: 10px;
            text-decoration: none;
            color: #333;
        }

        .user-dropdown a:hover {
            background-color: #000000;
        }
    </style>
</head>
<body>
<div class="user-menu">
        <div class="user-icon">
                <img src="icon.png" alt="User Icon">
            </div>
            <div class="user-dropdown">
                <a href="logout.php">Logout</a>
            </div>
        </div>
<div class="content">
    <h1>Purchase</h1>
    <div class="top-bar">
    <button onclick="location.href='dashboard.php'">Home</button>
    <div class="search-bar">
            <form method="GET" action="">
                <input type="text" name="search" placeholder="Search..." value="<?php echo htmlspecialchars($search); ?>">
                <button type="submit">Search</button>
            </form>
        </div>
    <div>
        
        <button onclick="location.href='?add=true'">New Record</button>
        <button onclick="window.print()">Print</button> 
        
    </div>
</div>
<table>
            <tr>
                <th style="background-color: #4caf50;">Date</th>
                <th style="background-color: #2196f3;">Name</th>
                <th style="background-color: #ff9800;">Address</th>
                <th style="background-color: #9c27b0;">Contact</th>
                <th style="background-color: #f44336;">Product ID</th>
                <th style="background-color: #00bcd4;">Product Name</th>
                <th style="background-color: #8bc34a;">Quantity</th>
                <th style="background-color: #ffeb3b;">Rate</th>
                <th style="background-color: #795548;">Discount</th>
                <th style="background-color: #9e9e9e;">GST</th>
                <th style="background-color: #607d8b;">CGST</th>
                <th style="background-color: #3f51b5;">Total</th>
                <th style="background-color: #e91e63;">Actions</th>
            </tr>
            <?php while($row = $result->fetch_assoc()): ?>
            <tr>
                <td><?php echo $row['date']; ?></td>
                <td><?php echo $row['name']; ?></td>
                <td><?php echo $row['address']; ?></td>
                <td><?php echo $row['contact']; ?></td>
                <td><?php echo $row['product_id']; ?></td>
                <td><?php echo $row['product_name']; ?></td>
                <td><?php echo $row['quantity']; ?></td>
                <td><?php echo $row['rate']; ?></td>
                <td><?php echo $row['discount']; ?></td>
                <td><?php echo $row['gst']; ?></td>
                <td><?php echo $row['cgst']; ?></td>
                <td><?php echo $row['total']; ?></td>
                <td>
                    <a class="btn edit" href="?edit=<?php echo $row['id']; ?>">Edit</a>
                    <a class="btn delete" href="?delete=<?php echo $row['id']; ?>">Delete</a>
                </td>
            </tr>
            <?php endwhile; ?>
        </table>
    <div class="pagination">
        <?php for ($i = 1; $i <= $total_pages; $i++) : ?>
            <a href="?page=<?php echo $i; ?>"><?php echo $i; ?></a>
        <?php endfor; ?>
    </div>

    <div class="form-section">
            <form id="newBuyerForm" method="POST" action="purchase.php">
                <input type="hidden" name="id" value="<?php echo $edit_id; ?>">
                <input type="date" name="date" placeholder="Date" value="<?php echo $edit_record['date'] ?? ''; ?>" required>
                <input type="text" name="name" placeholder="Name" value="<?php echo $edit_record['name'] ?? ''; ?>" required>
                <input type="text" name="address" placeholder="Address" value="<?php echo $edit_record['address'] ?? ''; ?>" required>
                <input type="text" name="contact" placeholder="Contact" value="<?php echo $edit_record['contact'] ?? ''; ?>" required>
                <input type="text" name="product_id" placeholder="Product ID" value="<?php echo $edit_record['product_id'] ?? ''; ?>" required>
                <input type="text" name="product_name" placeholder="Product Name" value="<?php echo $edit_record['product_name'] ?? ''; ?>" required>
                <input type="number" name="quantity" placeholder="Quantity" value="<?php echo $edit_record['quantity'] ?? ''; ?>" required>
                <input type="number" name="rate" placeholder="Rate" value="<?php echo $edit_record['rate'] ?? ''; ?>" required>
                <input type="number" name="discount" placeholder="Discount" value="<?php echo $edit_record['discount'] ?? ''; ?>" required>
                <input type="number" name="gst" placeholder="GST" value="<?php echo $edit_record['gst'] ?? ''; ?>" required>
                <input type="number" name="cgst" placeholder="CGST" value="<?php echo $edit_record['cgst'] ?? ''; ?>" required>
                <input type="number" name="total" placeholder="Total" value="<?php echo $edit_record['total'] ?? ''; ?>" required>
                <button type="submit" class="btn save">Save</button>
                <button type="button" class="btn cancel" onclick="window.location.href='?cancel=true'">Cancel</button>
            </form>
        </div>
</div>
<script>
    function loadContent(page) {
        fetch(page)
            .then(response => response.text())
            .then(data => {
                document.getElementById('content').innerHTML = data;
            })
            .catch(error => console.error('Error loading content:', error));
    }

    // Toggle user menu
    document.querySelector('.user-icon').addEventListener('click', () => {
        document.querySelector('.user-dropdown').classList.toggle('show');
    });

    // Close the dropdowns if the user clicks outside of them
    window.onclick = function(event) {
        if (!event.target.matches('.user-icon') && !event.target.matches('.user-icon img') && !event.target.matches('.notification-icon') && !event.target.matches('.notification-icon img')) {
            var dropdowns = document.getElementsByClassName("user-dropdown");
            for (var i = 0; i < dropdowns.length; i++) {
                var openDropdown = dropdowns[i];
                if (openDropdown.classList.contains('show')) {
                    openDropdown.classList.remove('show');
                }
            }
            }
        }
    </script>
</body>
</html>

<?php
$conn->close();
?>
