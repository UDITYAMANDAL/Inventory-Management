<?php
session_start();
if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit();
}

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "inventory";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize notifications
if (!isset($_SESSION['notifications'])) {
    $_SESSION['notifications'] = [];
}
$notifications = $_SESSION['notifications'];
$notification_count = isset($_SESSION['notification_count']) ? $_SESSION['notification_count'] : 0;

$notification = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $employee_id = $_POST["employee_id"] ?? "";
    $employee_name = $_POST["employee_name"] ?? "";

    // Check if employee ID already exists
    $id_check_query = "SELECT * FROM generate_id WHERE employee_id='$employee_id' LIMIT 1";
    $result = $conn->query($id_check_query);
    if ($result->num_rows > 0) {
        $notification = "Employee ID already exists.";
    } else {
        // Insert the new employee ID into the employees table
        $sql = "INSERT INTO generate_id (employee_id, employee_name) VALUES ('$employee_id', '$employee_name')";
        if ($conn->query($sql) === TRUE) {
            $notification = "Employee ID generated successfully.";
            $time = date('Y-m-d H:i:s');
            $_SESSION['notifications'][] = "Employee ID $employee_id created at $time.";
            $_SESSION['notification_count']++;
        } else {
            $notification = "Error: " . $sql . "<br>" . $conn->error;
        }
    }
}

// Fetch all employees
$employees_query = "SELECT id, employee_id,first_name, last_name, dob, gender, contact, company_name, company_email, email FROM data1";
$employees_result = $conn->query($employees_query);

$employees = [];
if ($employees_result->num_rows > 0) {
    while ($row = $employees_result->fetch_assoc()) {
        $employees[] = $row;
    }
}

// Fetch all generated employee IDs
$generated_ids_query = "SELECT employee_id, employee_name FROM generate_id";
$generated_ids_result = $conn->query($generated_ids_query);

$generated_ids = [];
if ($generated_ids_result->num_rows > 0) {
    while ($row = $generated_ids_result->fetch_assoc()) {
        $generated_ids[] = $row;
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Generate Employee ID</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            background-image: url('dash.png');
        }
        .container {
            width: 80%;
            margin: auto;
            overflow: hidden;
        }
        .content {
            margin: 20px;
            padding: 20px;
            background: white;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .content h1, .content h2 {
            margin-top: 0;
        }
        .form-group {
            margin-bottom: 15px;
            
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
            display: inline-block;
        }
        .form-group input {
            width: 30%;
            padding: 8px;
            box-sizing: border-box;
        }
        .form-group button {
            background: #28a745;
            color: white;
            border: none;
            padding: 10px 20px;
            cursor: pointer;
        }
        .form-group button:hover {
            background: #218838;
        }
        .table-container {
            margin-top: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            background: lightblue;
        }
        table, th, td {
            border: 1px solid black;
        }
        th, td {
            padding: 10px;
            text-align: left;
        }
        .hidden-details {
            display: none;
        }
        .notification {
            margin: 20px 0;
            padding: 10px;
            border-radius: 4px;
            color: white;
            background: #007bff;
            display: inline-block;
        }
    </style>
</head>
<body>
    <div class="container">
        <?php if ($notification): ?>
            <div class="notification">
                <p><?php echo $notification; ?></p>
            </div>
        <?php endif; ?>

        <div class="content">
            <h2>Generate Employee ID</h2>
            <form method="post">
                <div class="form-group">
                    <label for="employee_id">Employee ID:</label>
                    <input type="text" id="employee_id" name="employee_id" required>
                    <label for="employee_name">Employee Name:</label>
                    <input type="text" id="employee_name" name="employee_name" required>
                </div>
                <div class="form-group">
                    <button type="submit">Generate</button>
                </div>
            </form>
        </div>

        <div class="content">
            <h1>Employee List</h1>
            <div class="table-container">
                <table class="highlight">
                    <thead>
                        <tr>
                            <th>Sr no</th>
                            <th>Emp Id</th>
                            <th>Full Name</th>
                            <th>Email</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($employees as $index => $employee): ?>
                            <tr onclick="toggleEmployeeDetails('<?php echo $employee['id']; ?>')">
                                <td><?php echo $index + 1; ?></td>
                                <td><?php echo $employee['employee_id']; ?></td>
                                <td><?php echo $employee['first_name'] . ' ' . $employee['last_name']; ?></td>
                                <td><?php echo $employee['email']; ?></td>
                                <td>ACTIVE</td>
                            </tr>
                            <tr class="employee-details hidden-details" data-id="<?php echo $employee['id']; ?>">
                                <td colspan="5">
                                    <p>ID: <?php echo $employee['id']; ?></p>
                                    <p>Name: <?php echo $employee['first_name'] . ' ' . $employee['last_name']; ?></p>
                                    <p>dob: <?php echo $employee['dob']; ?></p>
                                    <p>Gender: <?php echo $employee['gender']; ?></p>
                                    <p>contact: <?php echo $employee['contact']; ?></p>
                                    <p>Company Email: <?php echo $employee['company_email']; ?></p>
                                    <p>Company Name: <?php echo $employee['company_name']; ?></p>
                                    <p>Email: <?php echo $employee['email']; ?></p>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <div class="content">
            <h1>Generated Employee IDs</h1>
            <div class="table-container">
                <table class="highlight">
                    <thead>
                        <tr>
                            <th>Employee ID</th>
                            <th>Employee Name</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($generated_ids as $generated_id): ?>
                            <tr>
                                <td><?php echo $generated_id['employee_id']; ?></td>
                                <td><?php echo $generated_id['employee_name']; ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <script>
        function toggleEmployeeDetails(id) {
            var detailsRow = document.querySelector('.employee-details[data-id="' + id + '"]');
            if (detailsRow.style.display === 'none' || detailsRow.style.display === '') {
                detailsRow.style.display = 'table-row';
            } else {
                detailsRow.style.display = 'none';
            }
        }

        document.querySelector('.notification-bar').addEventListener('click', function() {
            alert('<?php echo implode('\n', $_SESSION['notifications']); ?>');
            <?php $_SESSION['notifications'] = []; $_SESSION['notification_count'] = 0; ?>
        });

        document.addEventListener('DOMContentLoaded', function () {
            document.getElementById('notification-bar').addEventListener('click', function () {
                var notificationsContent = document.getElementById('notifications-content');
                if (notificationsContent.style.display === 'none') {
                    notificationsContent.style.display = 'block';
                } else {
                    notificationsContent.style.display = 'none';
                }
            });
        });
    </script>
</body>
</html>
