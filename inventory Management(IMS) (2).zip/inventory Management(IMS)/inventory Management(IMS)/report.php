<?php
session_start();
if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit();
}

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "inventory";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$search = isset($_GET['search']) ? $_GET['search'] : '';
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$records_per_page = 50;
$offset = ($page - 1) * $records_per_page;

$search_sql = $search ? "WHERE p.product_name LIKE '%$search%' OR s.product_id IN (SELECT product_id FROM purchase WHERE product_name LIKE '%$search%')" : '';

// Count total records
$count_sql = "SELECT COUNT(DISTINCT p.product_id) AS total FROM purchase p LEFT JOIN sell s ON p.product_id = s.product_id $search_sql";
$count_result = $conn->query($count_sql);
$total_records = $count_result->fetch_assoc()['total'];
$total_pages = ceil($total_records / $records_per_page);

// Fetch data with pagination
$purchase_query = "
    SELECT p.product_id, p.product_name, p.rate, SUM(p.quantity) AS purchase_quantity 
    FROM purchase p 
    $search_sql 
    GROUP BY p.product_id 
    LIMIT $offset, $records_per_page
";
$purchase_result = $conn->query($purchase_query);

$sell_query = "
    SELECT s.product_id, SUM(s.quantity) AS sell_quantity 
    FROM sell s
    GROUP BY s.product_id
";
$sell_result = $conn->query($sell_query);

$purchase_data = [];
$sell_data = [];

if ($purchase_result->num_rows > 0) {
    while ($row = $purchase_result->fetch_assoc()) {
        $purchase_data[$row['product_id']] = $row;
    }
}

if ($sell_result->num_rows > 0) {
    while ($row = $sell_result->fetch_assoc()) {
        $sell_data[$row['product_id']] = $row;
    }
}

// Fetch unread notification count
$unread_notifications_sql = "SELECT COUNT(*) as count FROM notifications WHERE is_read = 0";
$unread_notifications_result = $conn->query($unread_notifications_sql);
$unread_notifications_count = $unread_notifications_result->fetch_assoc()['count'];

echo '<!DOCTYPE html>';
echo '<html lang="en">';
echo '<head>';
echo '<meta charset="UTF-8">';
echo '<meta name="viewport" content="width=device-width, initial-scale=1.0">';
echo '<title>Product Report</title>';
echo '<link rel="stylesheet" href="report.css">';
echo '<style>
body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
           background: url(\'dash.png\');
        }
            h1 {
            color: #fff;
            text-align: center;
        }
            .content {
            margin: 30px;
            background-color: #222;
            padding: 30px;
            border-radius: 8px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            text-align: center;
        }
            th, td {
            padding: 12px;
            border: 1px solid #ddd;
            text-align: left;
            color: #fff;
        }
        th {
            background-color: #3f51b5;
        }
        td {
            background-color: #333;
        }
.search-box {
    text-align: center;
    margin: 20px auto;
}
.search-box input[type="text"] {
    padding: 10px;
    width: 300px;
    border: 1px solid #ddd;
    border-radius: 4px;
}
.search-box input[type="submit"] {
    padding: 10px 15px;
    border: 1px solid #ddd;
    border-radius: 4px;
    background-color: #5cb85c;
    color: white;
    cursor: pointer;
}
.search-box input[type="submit"]:hover {
    background-color: #4cae4c;
}
.pagination {
    text-align: center;
    margin: 20px auto;
}
.pagination a {
            padding: 10px;
            margin: 0 5px;
            background-color: #3f51b5;
            color: white;
            text-decoration: none;
            font-weight: bold;
            border-radius: 4px;
        }
        .pagination a.active {
            background-color: #ff5722;
        }
        .pagination a:visited {
            color: white;
        }
        .pagination .prev, .pagination .next {
            font-size: 18px;
        }
.date-time {
    text-align: right;
    margin: 50px;
    font-size: 14px;
    color: #555;
}
.top-bar {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 10px 20px;
    background-color: #007BFF;
    border-bottom: 1px solid #e9ecef;
    gap: 15px;
}
.top-bar h1 {
    margin: 0;
    flex-grow: 1;
    text-align: center;
}
.top-bar .user-menu {
    position: relative;
    display: inline-block;
}
.top-bar button {
    padding: 10px;
    background-color: black;
    color: white;
    border: 3px;
    cursor: pointer;
    gap: 15px;
}
.user-icon img {
    cursor: pointer;
    border-radius: 50%;
    height: 50px;
    width: 50px;
}
.user-dropdown {
    display: none;
    position: absolute;
    right: 0;
    background-color: #ffffff;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
}
.user-dropdown a {
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
}
.user-dropdown a:hover {
    background-color: #f1f1f1;
}
.user-menu:hover .user-dropdown {
    display: block;
}
.notification-icon {
    position: relative;
    cursor: pointer;
}
.notification-count {
    position: absolute;
    top: -5px;
    right: -5px;
    background-color: red;
    color: white;
    border-radius: 50%;
    padding: 2px 6px;
    font-size: 12px;
}
    .timestamp {
            text-align: right;
            margin-top: 10px;
            color:white;
        }
</style>';
echo '</head>';
echo '<body>';

echo '<div class="content">';
echo '<h1>Product Report</h1>';
echo '<div class="timestamp">' . date('Y-m-d H:i:s') . '</div>';
echo '<div class="top-bar">';
echo '<button onclick="location.href=\'dashboard.php\'">Home</button>';
echo '<div class="search-box">';
echo '<form action="report.php" method="get">';
echo '<input type="text" name="search" placeholder="Search product name" value="' . htmlspecialchars($search) . '">';
echo '<input type="submit" value="Search">';
echo '</form>';
echo '</div>';
echo '<button id="printBtn" class="btn print" onclick="window.print()">Print</button>';
echo '<div class="user-menu">';
echo '<div class="user-icon">';
echo '<img src="icon.png" alt="User Icon" width="30" height="30">';
echo '</div>';
echo '<div class="user-dropdown">';
echo '<a href="logout.php">Logout</a>';
echo '</div>';
echo '</div>';
echo '<div class="notification-icon" onclick="location.href=\'notifications.php\'">';
echo '<img src="notification.png" alt="Notifications" width="24" height="24">';
if ($unread_notifications_count > 0) {
    echo '<div class="notification-count">' . $unread_notifications_count . '</div>';
}

echo '</div>';
echo '</div>';
echo '<table>';
echo '<tr>';
echo '<th style="background-color: #f2a2e8;">Product ID</th>';
echo '<th style="background-color: #f2e2a2;">Product Name</th>';
echo '<th style="background-color: #a2f2e8;">Purchase Quantity</th>';
echo '<th style="background-color: #a2e8f2;">Sell Quantity</th>';
echo '<th style="background-color: #e8a2f2;">Remaining Quantity</th>';
echo '<th style="background-color: #f2a2a2;">Product Rate</th>';
echo '<th style="background-color: #a2a2f2;">Total</th>';
echo '</tr>';

$all_product_ids = array_unique(array_merge(array_keys($purchase_data), array_keys($sell_data)));

foreach ($all_product_ids as $product_id) {
    $purchase_quantity = isset($purchase_data[$product_id]['purchase_quantity']) ? $purchase_data[$product_id]['purchase_quantity'] : 0;
    $sell_quantity = isset($sell_data[$product_id]['sell_quantity']) ? $sell_data[$product_id]['sell_quantity'] : 0;
    $remaining_quantity = $purchase_quantity - $sell_quantity;
    $rate = isset($purchase_data[$product_id]['rate']) ? $purchase_data[$product_id]['rate'] : 0;
    $total_value = $remaining_quantity * $rate;
    $product_name = isset($purchase_data[$product_id]['product_name']) ? htmlspecialchars($purchase_data[$product_id]['product_name']) : 'N/A';

    echo '<tr>';
    echo '<td>' . $product_id . '</td>';
    echo '<td>' . $product_name . '</td>';
    echo '<td>' . $purchase_quantity . '</td>';
    echo '<td>' . $sell_quantity . '</td>';
    echo '<td>' . $remaining_quantity . '</td>';
    echo '<td>' . $rate . '</td>';
    echo '<td>' . $total_value . '</td>';
    echo '</tr>';
}

echo '</table>';
echo '</div>';

echo '<div class="pagination">';
for ($i = 1; $i <= $total_pages; $i++) {
    echo '<a href="report.php?page=' . $i . '&search=' . urlencode($search) . '">' . $i . '</a>';
}
echo '</div>';

echo '</body>';
echo '</html>';

$conn->close();
?>
