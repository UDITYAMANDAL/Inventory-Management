-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 07, 2024 at 01:56 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `inventory`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `department` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `buyers`
--

CREATE TABLE `buyers` (
  `id` int(11) NOT NULL,
  `date` date NOT NULL,
  `name` varchar(100) NOT NULL,
  `address` varchar(255) NOT NULL,
  `contact` varchar(50) NOT NULL,
  `product_id` varchar(50) NOT NULL,
  `product` varchar(100) NOT NULL,
  `type` varchar(50) NOT NULL,
  `rate` decimal(15,2) NOT NULL,
  `quantity` bigint(20) NOT NULL,
  `total` decimal(25,2) GENERATED ALWAYS AS (`rate` * `quantity`) STORED
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `data1`
--

CREATE TABLE `data1` (
  `id` int(11) NOT NULL,
  `employee_id` varchar(255) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `dob` date NOT NULL,
  `gender` enum('Male','Female','Other') NOT NULL,
  `contact` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `company_name` varchar(100) NOT NULL,
  `company_email` varchar(255) NOT NULL,
  `position` varchar(200) NOT NULL,
  `hint_answer1` varchar(255) NOT NULL,
  `hint_answer2` varchar(255) NOT NULL,
  `hint_answer3` varchar(255) NOT NULL,
  `hint_answer4` varchar(255) NOT NULL,
  `hint_answer5` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `data1`
--

INSERT INTO `data1` (`id`, `employee_id`, `first_name`, `last_name`, `username`, `dob`, `gender`, `contact`, `email`, `password`, `company_name`, `company_email`, `position`, `hint_answer1`, `hint_answer2`, `hint_answer3`, `hint_answer4`, `hint_answer5`, `created_at`) VALUES
(1, '', 'ABC', 'DEF', 'admin', '2000-10-31', 'Male', '6207750613', 'abc@gmail.com', '$2y$10$e2e375kXg6ssUeSNewO/Jujd1PNEkgeZG9hnxVu8/TyZt8YIBQ4Ga', 'Krupanidhi Degree College', '2009-06-30', '', 'dec 31', 'abinash', 'ironman', 'dark', 'dog', '2024-06-14 09:42:48'),
(2, '', 'JNS', 'Casa', 'jns', '2024-03-13', 'Male', '97546353278', 'abc@gmail.com', '$2y$10$Qge6LWqQXPTBSf8E4BITpORxiyvtp8JMVjxPcn/JE8uC1SPyX7iuC', 'dfdgsfg', '2024-06-18', '', 'dec 31', 'abinash', 'ironman', 'dark', 'dog', '2024-06-14 16:44:14'),
(3, 'empoo2', 'JNS', 'Casa', 'empoo2', '2024-07-02', 'Male', '1', 'ca@gmail.com', '$2y$10$ecrl7Dblc0Z7drVpqbvNY.ufRqHZWH0tsHlLB3Nm578GJS2fdgpha', 'abc', 'gfhghgh@gmail.com', '', '20 jan', 'potawali', 'gu', 'gu khalo', 'kutti', '2024-07-07 10:00:55'),
(4, 'EMP004', 'Sang', 'Test', 'Sang', '1111-01-01', 'Male', '8837280880', 'sangpangro007@gmail.com', '$2y$10$MmCxUDlKtCiptAEnGsqI8OpiFb4jMerCAixwLycKOBiroOAWKK5PC', 'ABCDE', 'sangpangro007@gmail.com', '', '0202', 'abc', 'def', 'ghi', 'jkl', '2024-07-07 11:50:55');

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE `employees` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `department` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `generate_id`
--

CREATE TABLE `generate_id` (
  `employee_id` varchar(255) NOT NULL,
  `employee_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `generate_id`
--

INSERT INTO `generate_id` (`employee_id`, `employee_name`) VALUES
('emp001', 'Uditya'),
('EMP004', 'Sang'),
('empoo2', ''),
('hi988', '');

-- --------------------------------------------------------

--
-- Table structure for table `logins`
--

CREATE TABLE `logins` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `login_time` datetime NOT NULL,
  `logout_time` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` int(11) NOT NULL,
  `message` text NOT NULL,
  `is_read` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `purchase`
--

CREATE TABLE `purchase` (
  `id` int(11) NOT NULL,
  `date` date NOT NULL,
  `name` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `contact` varchar(50) NOT NULL,
  `product_id` varchar(50) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `quantity` int(11) NOT NULL,
  `rate` decimal(10,2) NOT NULL,
  `discount` decimal(10,2) NOT NULL,
  `gst` decimal(10,2) NOT NULL,
  `cgst` decimal(10,2) NOT NULL,
  `total` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `purchase`
--

INSERT INTO `purchase` (`id`, `date`, `name`, `address`, `contact`, `product_id`, `product_name`, `quantity`, `rate`, `discount`, `gst`, `cgst`, `total`) VALUES
(1, '2023-01-01', 'John Doe', '123 Main St', '1234567890', 'P001', 'Product A', 111, 100.00, 10.00, 18.00, 9.00, 1091.00),
(2, '2023-01-02', 'Jane Smith', '456 Elm St', '0987654321', 'P002', 'Product B', 5, 200.00, 15.00, 18.00, 9.00, 1057.00),
(3, '2023-01-03', 'Alice Johnson', '789 Oak St', '1112223333', 'P003', 'Product C', 8, 150.00, 12.00, 18.00, 9.00, 1296.00),
(4, '2024-07-07', 'Bob', '145 George Street', '8760436241', 'P004', 'Product D', 19, 23.00, 2.00, 4.00, 6.00, 2345.00),
(5, '2024-07-07', 'Joy', '213 Gunjur Street', '9876123450', 'P005', 'Product E', 120, 55.00, 3.00, 6.00, 8.00, 55000.00);

-- --------------------------------------------------------

--
-- Table structure for table `sell`
--

CREATE TABLE `sell` (
  `id` int(11) NOT NULL,
  `date` date NOT NULL,
  `name` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `contact` varchar(50) NOT NULL,
  `product_id` varchar(50) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `quantity` int(11) NOT NULL,
  `rate` decimal(10,2) NOT NULL,
  `discount` decimal(10,2) NOT NULL,
  `gst` decimal(10,2) NOT NULL,
  `cgst` decimal(10,2) NOT NULL,
  `total` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sell`
--

INSERT INTO `sell` (`id`, `date`, `name`, `address`, `contact`, `product_id`, `product_name`, `quantity`, `rate`, `discount`, `gst`, `cgst`, `total`) VALUES
(1, '2023-01-01', 'John Doe', '123 Main St', '1234567890', 'P001', 'Product A', 10, 100.00, 10.00, 18.00, 9.00, 1091.00),
(2, '2023-01-02', 'Jane Smith', '456 Elm St', '0987654321', 'P002', 'Product B', 5, 200.00, 15.00, 18.00, 9.00, 1057.00),
(3, '2023-01-03', 'Alice Johnson', '789 Oak St', '1112223333', 'P003', 'Product C', 8, 150.00, 12.00, 18.00, 9.00, 1296.00);

-- --------------------------------------------------------

--
-- Table structure for table `seller`
--

CREATE TABLE `seller` (
  `id` int(11) NOT NULL,
  `date` date NOT NULL,
  `name` varchar(100) NOT NULL,
  `address` varchar(255) NOT NULL,
  `contact` varchar(50) NOT NULL,
  `product_id` varchar(50) NOT NULL,
  `product` varchar(100) NOT NULL,
  `type` varchar(50) NOT NULL,
  `rate` decimal(15,2) NOT NULL,
  `quantity` bigint(20) NOT NULL,
  `total` decimal(25,2) GENERATED ALWAYS AS (`rate` * `quantity`) STORED
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `seller`
--

INSERT INTO `seller` (`id`, `date`, `name`, `address`, `contact`, `product_id`, `product`, `type`, `rate`, `quantity`) VALUES
(1, '2024-06-19', 'dfxzbzdf', 'bxzbzxf', '46e74565', 'vxbvc', 'w4', 'bgbdf', 2334.00, 4343);

-- --------------------------------------------------------

--
-- Table structure for table `stock`
--

CREATE TABLE `stock` (
  `id` int(11) NOT NULL,
  `date` date NOT NULL,
  `prodid` varchar(50) NOT NULL,
  `prodname` varchar(100) NOT NULL,
  `prodtype` varchar(50) NOT NULL,
  `prodrate` decimal(10,2) NOT NULL,
  `prodquantity` int(11) NOT NULL,
  `sellerdetails` varchar(255) NOT NULL,
  `prodimage` varchar(255) NOT NULL,
  `stock_limit` int(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `stock`
--

INSERT INTO `stock` (`id`, `date`, `prodid`, `prodname`, `prodtype`, `prodrate`, `prodquantity`, `sellerdetails`, `prodimage`, `stock_limit`) VALUES
(1, '2024-06-19', 'fdf', 'dsf', 'safdsa', 1212.00, 12122, 'zxvvc', 'uploads/1613632505phpmq0lVI.jpg', 0),
(3, '2024-05-14', '876', 'abc', 'wsss', 233.00, 232, '1saczxz', '', 0),
(4, '2024-05-27', '22', 'apple', 'bnmbv', 21.00, 212, '122', '', 0),
(6, '2001-01-21', '98', 'laptop', 'electronics', 321.00, 1000, 'ElectronicHub ', '', 0),
(7, '2024-06-20', 'a1', 'Mango', 'Fruit', 10.00, 78, 'Abcdefg', '', 0),
(8, '2024-06-21', 'a2', 'Apple', 'Fruit', 15.00, 47, 'Raju', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `stockout`
--

CREATE TABLE `stockout` (
  `id` int(11) NOT NULL,
  `date` date NOT NULL,
  `prodid` varchar(50) NOT NULL,
  `prodname` varchar(100) NOT NULL,
  `prodtype` varchar(50) NOT NULL,
  `prodrate` decimal(10,2) NOT NULL,
  `prodquantity` int(11) NOT NULL,
  `sellerdetails` varchar(255) NOT NULL,
  `prodimage` varchar(255) NOT NULL,
  `stockout_limit` int(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `stockout`
--

INSERT INTO `stockout` (`id`, `date`, `prodid`, `prodname`, `prodtype`, `prodrate`, `prodquantity`, `sellerdetails`, `prodimage`, `stockout_limit`) VALUES
(3, '2024-05-14', '876', 'abc', 'wsss', 233.00, 100, '1saczxz', '', 150),
(4, '2024-05-27', '22', 'apple', 'bnmbv', 21.00, 100, '122', '', 0),
(5, '2024-05-13', '323', '122', 'SSAD', 323.00, 150, 'adsd', '', 0),
(6, '2001-01-21', '98', 'laptop', 'electronics', 321.00, 300, 'ElectronicHub ', '', 400);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `access` tinyint(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user_issues`
--

CREATE TABLE `user_issues` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `issue` text NOT NULL,
  `solution` text DEFAULT NULL,
  `status` enum('pending','resolved') DEFAULT 'pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_issues`
--
--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `buyers`
--
ALTER TABLE `buyers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `product_id` (`product_id`);

--
-- Indexes for table `data1`
--
ALTER TABLE `data1`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `employees`
--
ALTER TABLE `employees`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `generate_id`
--
ALTER TABLE `generate_id`
  ADD UNIQUE KEY `employee_id` (`employee_id`);

--
-- Indexes for table `logins`
--
ALTER TABLE `logins`
  ADD PRIMARY KEY (`id`),
  ADD KEY `username` (`username`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `purchase`
--
ALTER TABLE `purchase`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sell`
--
ALTER TABLE `sell`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `seller`
--
ALTER TABLE `seller`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `product_id` (`product_id`);

--
-- Indexes for table `stock`
--
ALTER TABLE `stock`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `stockout`
--
ALTER TABLE `stockout`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_issues`
--
ALTER TABLE `user_issues`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `buyers`
--
ALTER TABLE `buyers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `data1`
--
ALTER TABLE `data1`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `employees`
--
ALTER TABLE `employees`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `logins`
--
ALTER TABLE `logins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `purchase`
--
ALTER TABLE `purchase`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `sell`
--
ALTER TABLE `sell`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `seller`
--
ALTER TABLE `seller`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `stock`
--
ALTER TABLE `stock`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `stockout`
--
ALTER TABLE `stockout`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_issues`
--
ALTER TABLE `user_issues`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
