<?php
session_start();
if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit();
}

// Function to add a notification
function addNotification($message) {
    if (!isset($_SESSION['notifications'])) {
        $_SESSION['notifications'] = [];
    }
    $_SESSION['notifications'][] = $message;
}

// Example of adding a notification (this should be done wherever a change is made, e.g., after a product is sold)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Assume some form processing here
    // Example notification
    addNotification("A product has been sold from inventory.");
}

// Function to get all notifications
function getNotifications() {
    return isset($_SESSION['notifications']) ? $_SESSION['notifications'] : [];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inventory & Account Management Dashboard</title>
    
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            font-size: 16px;
            background-image: url('dash.png');
            background-size: cover;
            background-attachment: fixed;
        }

        .sidebar {
            height: 100%;
            width: 150px;
            position: fixed;
            top: 0;
            left: 0;
            background-color: #3f51b5;
            padding-top: 20px;
        }

        .sidebar h2 {
            color: #fff;
            text-align: center;
        }

        .sidebar ul {
            list-style-type: none;
            padding: 0;
            text-align: center;
        }

        .sidebar ul li {
            padding: 15px;
        }

        .sidebar ul li a {
            color: #fff;
            text-decoration: none;
        }

        .sidebar ul li a:hover {
            background-color: #1a237e;
        }

        .dropdown {
            position: relative;
        }

        .dropbtn {
            background-color: #3f51b5;
            color: rgb(255, 238, 238);
            padding: none;
            font-size: 16px;
            border: none;
            cursor: pointer;
        }

        .dropdown-content {
            display: none;
            position: relative;
            left: 0;
            top: 100%;
            background-color: rgba(255, 255, 255, 0.8);
            color: black;
            min-width: 160px;
            box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
            z-index: 1;
        }

        .dropdown-content a {
            color: black;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
            font-weight: bold;
            background-color: transparent;
        }

        .dropdown-content a:hover {
            background-color: rgba(230, 230, 230, 0.8);
        }

        .dropdown:hover .dropdown-content {
            display: block;
        }

        .nav {
            background-color: lightblue;
            padding: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-left: 150px;
        }

        .content {
            margin-left: 150px;
            padding: 20px;
            color: rgb(236, 36, 36);
            height: 1px;
            width: 50%;
            background-color: rgb(36,143,236);
        }

        .user-menu {
            display: flex;
            align-items: center;
            justify-content: flex-end;
            position: relative;
        }

        .user-icon img {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            cursor: pointer;
        }

        .user-dropdown {
            display: none;
            position: absolute;
            top: 50px;
            right: 0;
            color: black;
            background-color: #fff;
            border: 1px solid #ccc;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            z-index: 1;
        }

        .user-dropdown.show {
            display: block;
        }

        .user-dropdown a {
            display: block;
            padding: 10px;
            text-decoration: none;
            color: #333;
        }

        .user-dropdown a:hover {
            background-color: #000000;
        }
        .user-info-container {
    background-color: #fff;
    padding: 20px;
    border: 1px solid #ccc;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    position: absolute;
    top: 70px; /* Adjust according to your layout */
    right: 10px;
    width: calc(100% - 170px); /* Adjust to fit your layout */
    max-width: 400px;
    color: black;
}

.user-info-container h2 {
    margin-top: 0;
}

.user-info-container ul {
    list-style-type: none;
    padding: 0;
}

.user-info-container li {
    font-weight: bold;
    margin-bottom: 10px;
}


        .notification-icon img {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            cursor: pointer;
            margin-right: 10px;
        }

        .notification-dropdown {
            display: none;
            position: absolute;
            top: 50px;
            right: 60px; /* Adjust this position based on your layout */
            color: black;
            background-color: #fff;
            border: 1px solid #ccc;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            z-index: 1;
        }

        .notification-dropdown.show {
            display: block;
        }

        .notification-dropdown a {
            display: block;
            padding: 10px;
            text-decoration: none;
            color: #333;
            font-weight: bold;
        }

        .notification-dropdown a:hover {
            background-color: #000000;
        }
    </style>
</head>
<body>
    <div class="sidebar">
        <h2>Dashboard</h2>
        <ul>
            <li><a href="dashboard.php">Home</a></li>
            <li class="dropdown">
                <button class="dropbtn">Menu--></button>
                <div class="dropdown-content">
                    <a href="purchase.php">Purchase</a>
                    <a href='sell.php'>Sell</a>
                    <a href="report.php">Report</a>
                </div>
            </li><br>
            <li class="dropdown">
                <button class="dropbtn">Inventory --></button>
                <div class="dropdown-content">
                    <a href='stockin.php'>Stock in</a>
                    <a href="stockout.php">Stock Out</a>
                    <a href="stkreport.php">Total Stock</a>
                </div>
            </li><br>
            <li class="dropdown">
                <button class="dropbtn">Merchant --></button>
                <div class="dropdown-content">
                    <a href='buyers.php'>Buyers</a>
                    <a href="seller.php">Seller</a>
                </div>
            </li><br>
            <li class="dropdown">
                <button class="dropbtn">Limiter --></button>
                <div class="dropdown-content">
                    <a href="limit.php">Set limit</a>
                </div>
            </li><br>
            <li><a href="employee_issues.php">Help?</a></li>
        </ul>
    </div>

    <div class="nav">
        <div>
            <h2>Welcome to the Inventory & Account Management Dashboard.</h2>
        </div>
        <div class="user-menu">
            <div class="notification-icon">
                <img src="notification.png" alt="Notification Icon">
            </div>
            <div class="notification-dropdown">
                <?php foreach (getNotifications() as $notification): ?>
                    <a href="summary.php"><?= $notification ?></a>
                <?php endforeach; ?>
            </div>
            <div class="user-icon">
                <img src="icon.png" alt="User Icon">
            </div>
            <div class="user-dropdown">
                <a href="#" onclick="loadContent('userinfo.php')">User Information</a>
                <a href='#' onclick="loadContent('update.php')">Update Information</a>
                <a href="updatepassword.php">Change Password</a>
                <a href="logout.php">Logout</a>
            </div>
        </div>
    </div>
    <div id="content">

    </div>

    <script>
    function loadContent(page) {
        fetch(page)
            .then(response => response.text())
            .then(data => {
                document.getElementById('content').innerHTML = data;
            })
            .catch(error => console.error('Error loading content:', error));
    }

    // Toggle user menu
    document.querySelector('.user-icon').addEventListener('click', () => {
        document.querySelector('.user-dropdown').classList.toggle('show');
    });

    // Toggle notification menu
    document.querySelector('.notification-icon').addEventListener('click', () => {
        document.querySelector('.notification-dropdown').classList.toggle('show');
    });

    // Close the dropdowns if the user clicks outside of them
    window.onclick = function(event) {
        if (!event.target.matches('.user-icon') && !event.target.matches('.user-icon img') && !event.target.matches('.notification-icon') && !event.target.matches('.notification-icon img')) {
            var dropdowns = document.getElementsByClassName("user-dropdown");
            for (var i = 0; i < dropdowns.length; i++) {
                var openDropdown = dropdowns[i];
                if (openDropdown.classList.contains('show')) {
                    openDropdown.classList.remove('show');
                }
            }

            var notifications = document.getElementsByClassName("notification-dropdown");
            for (var i = 0; i < notifications.length; i++) {
                var openNotification = notifications[i];
                if (openNotification.classList.contains('show')) {
                    openNotification.classList.remove('show');
                }
            }
        }
    }
    </script>
</body>
</html>