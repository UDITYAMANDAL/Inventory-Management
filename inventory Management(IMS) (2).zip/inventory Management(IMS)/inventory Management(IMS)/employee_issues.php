<?php
session_start();
if (!isset($_SESSION['username'])) {
    echo "<p>You are not logged in. Please login to use the help page.</p>";
    exit();
}

$username = $_SESSION['username'];

// Establish database connection
$servername = "localhost";
$db_username = "root"; // default username for XAMPP
$db_password = ""; // default password for XAMPP
$database = "inventory"; // Replace with your database name
$conn = new mysqli($servername, $db_username, $db_password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form submission for new issues
$notification = "";
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['subject']) && isset($_POST['description'])) {
    $subject = $_POST['subject'];
    $description = $_POST['description'];

    $sql = "INSERT INTO user_issues (username, subject, issue) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sss", $username, $subject, $description);

    if ($stmt->execute()) {
        $notification = "Your issue has been submitted successfully.";
    } else {
        $notification = "Error submitting your issue: " . $stmt->error;
    }
    $stmt->close();
}

// Fetch issues raised by the logged-in user
$sql = "SELECT id, subject, issue, solution, status FROM user_issues WHERE username = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();
$issues = [];

while ($row = $result->fetch_assoc()) {
    $issues[] = $row;
}

$stmt->close();
$conn->close();

// Replace with your admin contact details
$admin_email = "admin@example.com";
$admin_phone = "+1234567890";
$admin_whatsapp = "+1234567890";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Issues - Inventory and Account Management</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-image: url('dash.png');
            background-size: cover;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .container {
            width: 600px;
            padding: 20px;
            background-color: gray;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        h2 {
            text-align: center;
            margin-bottom: 20px;
        }
        form {
            margin-bottom: 20px;
        }
        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        input, textarea {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }
        button {
            width: 100%;
            padding: 10px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        button:hover {
            background-color: #0056b3;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        table, th, td {
            border: 1px solid #ccc;
        }
        th, td {
            padding: 10px;
            text-align: left;
        }
        .status-resolved {
            color: green;
        }
        .status-pending {
            color: red;
        }
        .contact-info {
            text-align: center;
            margin-top: 20px;
        }
        .contact-info p {
            margin: 5px 0;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>My Issues</h2>
        <?php if ($notification): ?>
            <p><?php echo $notification; ?></p>
        <?php endif; ?>
        <form method="post">
            <label for="subject">Subject:</label>
            <input type="text" id="subject" name="subject" required>
            <label for="description">Describe your issue:</label>
            <textarea id="description" name="description" rows="4" required></textarea>
            <button type="submit">Submit</button>
        </form>
        <div class="contact-info">
        <h3>Contact Information</h3>
        <p>Email: <a href="mailto:<?php echo $admin_email; ?>"><?php echo $admin_email; ?></a></p>
        <p>Phone: <a href="tel:<?php echo $admin_phone; ?>"><?php echo $admin_phone; ?></a></p>
        <p>WhatsApp: <a href="https://wa.me/<?php echo preg_replace('/[^0-9]/', '', $admin_whatsapp); ?>"><?php echo $admin_whatsapp; ?></a></p>
    </div>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Subject</th>
                    <th>Issue</th>
                    <th>Solution</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($issues as $issue): ?>
                    <tr>
                        <td><?php echo $issue['id']; ?></td>
                        <td><?php echo $issue['subject']; ?></td>
                        <td><?php echo $issue['issue']; ?></td>
                        <td><?php echo $issue['solution']; ?></td>
                        <td class="<?php echo $issue['status'] === 'resolved' ? 'status-resolved' : 'status-pending'; ?>">
                            <?php echo ucfirst($issue['status']); ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    
</body>
</html>
