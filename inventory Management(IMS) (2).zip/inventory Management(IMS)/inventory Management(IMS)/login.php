<?php
session_start();
$notification = "";

// Establish database connection
$servername = "localhost";
$username = "root"; // default username for XAMPP
$password = ""; // default password for XAMPP
$database = "inventory"; // Replace with your database name
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    $notification = "Connection failed: " . $conn->connect_error;
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["login"])) {
    // Retrieve form data
    $identifier = $_POST["identifier"];
    $password = $_POST["password"];
    $role = $_POST["role"];

    // Fixed admin credentials
    $admin_username = 'ADMIN';
    $admin_password = 'Test@12345';

    if ($role === 'admin' && $identifier === $admin_username && $password === $admin_password) {
        // Admin login
        $_SESSION['username'] = $admin_username;
        $_SESSION['is_admin'] = true;
        header('Location: admin_dashboard.php');
        exit(); // Ensure no further output is sent
    } else if ($role === 'employee') {
        // Perform SQL query to check if user exists with provided email or username
        $sql = "SELECT * FROM data1 WHERE email='$identifier' OR username='$identifier'";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            $user = $result->fetch_assoc();
            if (password_verify($password, $user['password'])) {
                // Password is correct
                $_SESSION['username'] = $user['username'];
                $_SESSION['is_admin'] = false;
                header('Location: dashboard.php');
                exit(); // Ensure no further output is sent
            } else {
                // Password is incorrect
                $notification = "Invalid credentials.";
            }
        } else {
            // No user found with provided email or username
            $notification = "Invalid credentials.";
        }
    } else {
        // Invalid role or credentials
        $notification = "Invalid role or credentials.";
    }
}

// Close database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Inventory and Account Management</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-image: url('login.jpeg');
            background-size: cover;
            background-attachment: fixed;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .container {
            text-align: center;
        }
        h1 {
            font-size: 36px;
            background-color: rgba(255, 255, 255, 0.8);
            padding: 10px;
            border-radius: 8px;
            display: inline-block;
        }
        .login-options {
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .login-options div {
            margin: 20px;
            cursor: pointer;
            text-align: center;
        }
        .login-options img {
            width: 150px;
            height: 150px;
            border: 3px solid red;
            border-radius: 50%;
            transition: transform 0.2s, background-color 0.2s;
        }
        .login-options p {
            font-size: 24px;
            margin-top: 10px;
        }
        .selected img {
            transform: scale(1.1);
            background-color: blue;
        }
        .login-container {
            width: 300px;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            margin-top: 20px;
            display: none;
        }
        .login-container h2 {
            text-align: center;
            margin-bottom: 20px;
        }
        .login-form input[type="text"],
        .login-form input[type="password"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }
        .login-form button {
            width: 100%;
            padding: 10px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        .login-form button:hover {
            background-color: #0056b3;
        }
        .login-form a {
            text-decoration: none;
            color: #007bff;
            font-size: 14px;
            display: block;
            text-align: center;
        }
        .notification {
            position: fixed;
            top: 0;
            width: 100%;
            text-align: center;
            background-color: #fff;
            padding: 10px;
            border-bottom: 2px solid #ccc;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        .notification p {
            color: red;
            font-weight: bold;
            margin: 0;
        }
    </style>
</head>
<body>
    <?php if ($notification): ?>
        <div class="notification">
            <p><?php echo $notification; ?></p>
        </div>
    <?php endif; ?>

    <div class="container">
        <h1>Inventory and Account Management</h1>
        <div class="login-options">
            <div id="adminOption" onclick="showLoginForm('admin')">
                <img src="icon.png" alt="Admin">
                <p>Admin</p>
            </div>
            <div id="employeeOption" onclick="showLoginForm('employee')">
                <img src="icon.png" alt="Employee">
                <p>Employee</p>
            </div>
        </div>

        <div id="loginForm" class="login-container">
            <h2>Login</h2>
            <form class="login-form" action="login.php" method="post">
                <input type="hidden" id="role" name="role" value="">
                <label for="identifier">Email or Username:</label>
                <input type="text" id="identifier" name="identifier" required><br>
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" required><br>
                <button type="submit" name="login">Login</button>
                <div id="employeeExtras">
                    <a href="signup.php">Sign Up</a>
                    <a href="forgotword.php">Forgot Password?</a>
                </div>
            </form>
        </div>
    </div>

    <script>
        function showLoginForm(role) {
            const loginForm = document.getElementById('loginForm');
            const roleInput = document.getElementById('role');
            const adminOption = document.getElementById('adminOption');
            const employeeOption = document.getElementById('employeeOption');
            const employeeExtras = document.getElementById('employeeExtras');

            roleInput.value = role;

            loginForm.style.display = 'block';

            adminOption.classList.remove('selected');
            employeeOption.classList.remove('selected');

            if (role === 'admin') {
                adminOption.classList.add('selected');
                employeeExtras.style.display = 'none';
            } else {
                employeeOption.classList.add('selected');
                employeeExtras.style.display = 'block';
            }
        }

        function closeForm() {
            document.getElementById('loginForm').style.display = 'none';
        }

        window.onload = function() {
            closeForm(); // Close forms on page load
        };
    </script>
</body>
</html>
