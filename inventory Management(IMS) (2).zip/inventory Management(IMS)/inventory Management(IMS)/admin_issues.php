<?php
session_start();

// Check if user is logged in and is admin
if (!isset($_SESSION['username']) || !isset($_SESSION['is_admin']) || !$_SESSION['is_admin']) {
    header('Location: login.php');
    exit();
}

// Establish database connection
$servername = "localhost";
$username = "root"; // default username for XAMPP
$password = ""; // default password for XAMPP
$database = "inventory"; // Replace with your database name
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form submission for providing solutions
$notification = "";
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['issue_id']) && isset($_POST['solution'])) {
    $issue_id = $_POST['issue_id'];
    $solution = $_POST['solution'];

    $sql = "UPDATE user_issues SET solution = ?, status = 'resolved' WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("si", $solution, $issue_id);

    if ($stmt->execute()) {
        $notification = "Solution submitted successfully.";
    } else {
        $notification = "Error submitting solution: " . $stmt->error;
    }
    $stmt->close();
}

// Fetch all issues
$sql = "SELECT u.id, CONCAT(d.first_name, ' ', d.last_name) AS name, u.subject, u.issue, u.solution, u.status 
        FROM user_issues u
        JOIN data1 d ON u.username = d.username";
$result = $conn->query($sql);
$issues = [];

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $issues[] = $row;
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Issues - Inventory and Account Management</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            display: flex;
            height: 100vh;
            background-image: url('dash.png');
        }
        .sidebar {
            width: 250px;
            background-color: #004d40;
            color: #fff;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            overflow-y: auto;
            padding-top: 20px;
        }
        .sidebar h2 {
            text-align: center;
            margin-bottom: 20px;
        }
        .sidebar ul {
            list-style: none;
            padding: 0;
        }
        .sidebar ul li {
            padding: 10px 20px;
        }
        .sidebar ul li:hover {
            background-color: #00695c;
            cursor: pointer;
        }
        .sidebar img {
            display: block;
            margin: 0 auto 10px;
            width: 100px;
            transition: transform 0.2s, background-color 0.2s;
        }
        .sidebar ul li a {
            color: #fff;
            text-decoration: none;
            display: block;
        }
        .content {
            margin-left: 250px;
            padding: 20px;
            flex: 1;
        }
        .content h1 {
            background-color: blueviolet;
            margin-top: 0;
            display: inline-block;
        }
        .table-container {
            margin-top: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            background: lightblue;
        }
        table, th, td {
            border: 1px solid black;
        }
        th, td {
            padding: 10px;
            text-align: left;
        }
        .hidden-details {
            display: none;
        }
        .issue-text {
            color: black;
            font-weight: bold;
        }
        .solution-text {
            color: black;
        }
        .subject-text {
            color: red;
        }
    </style>
    <script>
        function showIssueDetails(id) {
            const rows = document.querySelectorAll('.issue-details');
            rows.forEach(row => {
                if (row.dataset.id === id) {
                    row.classList.toggle('hidden-details');
                }
            });
        }
    </script>
</head>
<body>
    <div class="sidebar">
        <img src="icon.png" alt="Admin">
        <h2>Admin</h2>
        <ul>
            <li><a href="admin_dashboard.php">Dashboard</a></li>
            <li><a href="employee.php">Generate ID</a></li>
            <li><a href="admin_issues.php">Issues</a></li>
            <li><a href="logout.php">Sign Out</a></li>
        </ul>
    </div>
    <div class="content">
        <h1>Employee Issues</h1>
        <?php if ($notification): ?>
            <p><?php echo $notification; ?></p>
        <?php endif; ?>
        <div class="table-container">
            <table class="highlight">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Subject</th>
                        <th>Issue</th>
                        <th>Solution</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($issues as $issue): ?>
                        <tr onclick="showIssueDetails('<?php echo $issue['id']; ?>')">
                            <td><?php echo $issue['id']; ?></td>
                            <td><?php echo $issue['name']; ?></td>
                            <td class="subject-text"><?php echo $issue['subject']; ?></td>
                            <td class="issue-text"><?php echo $issue['issue']; ?></td>
                            <td class="solution-text"><?php echo $issue['solution']; ?></td>
                            <td><?php echo $issue['status']; ?></td>
                            <td>
                                <form method="post">
                                    <input type="hidden" name="issue_id" value="<?php echo $issue['id']; ?>">
                                    <textarea name="solution" placeholder="Provide a solution" required></textarea>
                                    <button type="submit">Submit Solution</button>
                                </form>
                            </td>
                        </tr>
                        <tr class="issue-details hidden-details" data-id="<?php echo $issue['id']; ?>">
                            <td colspan="7">
                                <p><strong>Issue:</strong> <?php echo $issue['issue']; ?></p>
                                <p><strong>Solution:</strong> <?php echo $issue['solution']; ?></p>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>
